/*
 * Yuval Levy
 * 205781966
 */
package tasks;

import interfaces.Task;

/**
 * when q is pressed this task will close.
 */
public class CloseGame implements Task<Void> {
    /**
     * exits from the Game.
     *
     * @return null.
     */
    public Void run() {
        System.exit(1);
        return null;
    }
}
