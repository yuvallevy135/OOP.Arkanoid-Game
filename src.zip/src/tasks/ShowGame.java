/*
 * Yuval Levy
 * 205781966
 */
package tasks;

import interfaces.LevelInformation;
import thehighscoretablepackage.GameFlow;

import java.util.List;

import interfaces.Task;

/**
 * when s is pressed the task will run the level of the game from the game flow.
 */
public class ShowGame implements Task<Void> {
    private GameFlow gameFlow;
    private List<LevelInformation> theLevels;

    /**
     * constructor.
     *
     * @param gameFlow  the game flow
     * @param theLevels the the levels
     */
    public ShowGame(GameFlow gameFlow, List<LevelInformation> theLevels) {
        this.gameFlow = gameFlow;
        this.theLevels = theLevels;
    }

    /**
     * runs the game.
     *
     * @return null.
     */
    public Void run() {
        this.gameFlow.runLevels(this.theLevels);
        return null;
    }
}
