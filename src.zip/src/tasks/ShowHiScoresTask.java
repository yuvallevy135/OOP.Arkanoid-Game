/*
 * Yuval Levy
 * 205781966
 */
package tasks;
import interfaces.Task;
import animation.AnimationRunner;
import animation.KeyPressStoppableAnimation;
import biuoop.KeyboardSensor;
import interfaces.Animation;

/**
 * when h is pressed the task will run the animation it has.
 */
public class ShowHiScoresTask implements Task <Void>  {
    private AnimationRunner runner;
    private Animation highScores;
    private KeyboardSensor ks;

    /**
     * Constructor.
     *
     * @param runner     the runner
     * @param highScores the high scores
     * @param ks         the ks
     */
    public ShowHiScoresTask(AnimationRunner runner, Animation highScores, KeyboardSensor ks){
        this.runner = runner;
        this.ks = ks;
        this.highScores = highScores;
    }
    /**
     * runs this animation.
     *
     * @return null.
     */
    public Void run() {
        this.runner.run(new KeyPressStoppableAnimation(ks, ks.SPACE_KEY, this.highScores));
        return null;
    }
}
