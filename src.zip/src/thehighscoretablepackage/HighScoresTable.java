/*
 * Yuval Levy
 * 205781966
 */
package thehighscoretablepackage;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;

/**
 * Create an empty high-scores table with the specified size.
 * The size means that the table holds up to size top scores.
 */
public class HighScoresTable implements Serializable {

    //fields.
    private List<ScoreInfo> scoreInfoList;
    private int maxSize;

    /**
     * creating an empty high score table
     *
     * @param size the max scores in the table.
     */
    public HighScoresTable(int size) {
        scoreInfoList = new ArrayList<ScoreInfo>();
        this.maxSize = size;
    }

    /**
     * Add high score.
     *
     * @param score the score
     */

    public void add(ScoreInfo score) {
        // the rank where the score should be.
        int rank = getRank(score.getScore());
        if (rank > 0) {
            scoreInfoList.add(rank - 1, score);
        }
    }

    /**
     * return the amount of scores in the table.
     *
     * @return the size of the table.
     */
    public int size() {
        if (this.scoreInfoList.size() < maxSize) {
            return this.scoreInfoList.size();
        } else {
            return maxSize;
        }
    }

    /**
     * Return the current high scores.
     * The list is sorted such that the highest scores come first.
     *
     * @return the high scores list.
     */

    public List<ScoreInfo> getHighScores() {
        return this.scoreInfoList;
    }

    /**
     * return the rank of the current score: where will it
     * be on the list if added?
     * Rank 1 means the score will be highest on the list.
     * rank `size` means the score will be lowest.
     * Rank > `size` means the score is too low and will not
     * be added to the list.
     *
     * @param score the score we want to check.
     * @return the index that tells us if to add or not.
     */

    public int getRank(int score) {
        for (int i = 0; i < size(); i++) {
            if (score > this.scoreInfoList.get(i).getScore()) {
                return i + 1;
            }
        }
        if (size() < maxSize) {
            return (size() + 1);
        }
        return -1;
    }

    /**
     * Clears the table.
     */
    public void clear() {
        this.scoreInfoList.clear();
    }

    /**
     * Load table data from file.
     * Current table data is cleared.
     *
     * @param filename the filename that has the table.
     * @throws IOException the io exception that might happened.
     */

    public void load(File filename) throws IOException {
        // loadin the table.
        HighScoresTable scoresTable = HighScoresTable.loadFromFile(filename);
        // if the table is not empty - uptade the values.
        if (scoresTable != null) {
            this.scoreInfoList = scoresTable.scoreInfoList;
            this.maxSize = scoresTable.maxSize;
        }
    }

    /**
     * Save table data to the specified file..
     *
     * @param filename the filename that has the table.
     * @throws IOException the io exception
     */

    public void save(File filename) throws IOException {
        FileOutputStream fileOutputStream;
        ObjectOutputStream objectOutputStream = null;
        // we want to sav the filename. we will open filename for writing and we will
        // write into high scores table after.
        try {
            fileOutputStream = new FileOutputStream(filename);
            objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(this);
        } catch (Exception e) {
            System.out.println("Something wrong while trying to write.");
        } finally {
            if (objectOutputStream != null) {
                try {
                    objectOutputStream.close();
                } catch (IOException e) {
                    System.out.println("Fail closing the file.");
                }
            }
        }
    }

    /**
     * Read a table from file and return it.
     * If the file does not exist, or there is a problem with
     * reading it, an empty table is returned.
     *
     * @param filename the filename
     * @return the high scores table
     */
    public static HighScoresTable loadFromFile(File filename) {
        FileInputStream fileInputStream = null;
        // trying to load the high score table.
        try {
            fileInputStream = new FileInputStream(filename);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            return (HighScoresTable) objectInputStream.readObject();
            // if cant - create a new file and return a new table.
        } catch (Exception e) {
            try {
                // create a new highscores.txt if we dont have one like this.
                filename.createNewFile();
            } catch (IOException exception) {
                System.out.println("Cant create a new highscore.txt file");
            }
            HighScoresTable highScoresTable = new HighScoresTable(5);
            try {
                // save the new table.
                highScoresTable.save(filename);
            } catch (IOException e1) {
                System.out.println("Cant save the new table to the highscores.txt");
            }
            return highScoresTable;
        } finally {
            try {
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
            } catch (IOException e) {
                System.out.println("Fail to close highscore.txt file");
            }
        }
    }
}
