/*
 * Yuval Levy
 * 205781966
 */

package thehighscoretablepackage;

import java.io.Serializable;

/**
 * show the info about the members in HighScoreTable. Has name and score.
 */
public class ScoreInfo implements Serializable {
    private String name;
    private int score;

    /**
     * Constructor.
     *
     * @param name  the name
     * @param score the score
     */
    public ScoreInfo(String name, int score) {
        this.name = name;
        this.score = score;
    }

    /**
     * Get player's name.
     *
     * @return this.name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Get player's score.
     *
     * @return this.score
     */
    public int getScore() {
        return this.score;
    }
}
