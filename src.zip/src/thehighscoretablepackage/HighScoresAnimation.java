/*
 * Yuval Levy
 * 205781966
 */
package thehighscoretablepackage;

import biuoop.DrawSurface;
import interfaces.Animation;

import java.awt.Color;

/**
 * create the graphic according to the scores. show the tabele until SPACE is pressed.
 */
public class HighScoresAnimation implements Animation {
    private boolean stopIt;
    private HighScoresTable scores;

    /**
     * constructor.
     *
     * @param scores the scores
     */
    public HighScoresAnimation(HighScoresTable scores) {
        this.scores = scores;
        this.stopIt = false;
    }

    /**
     * in charge of the logic of this animation.
     *
     * @param d this drawsurface.
     */
    public void doOneFrame(DrawSurface d) {
        int height = d.getHeight() / 5;
        int widthName = d.getWidth() / 6;
        int widthScore = d.getWidth() - 250;
        int spaces = 45;
        d.setColor(new Color(0xBCBC95));
        d.fillRectangle(0, 0, 800, 600);
        d.setColor(new Color(0xE6DA27));
        d.fillRectangle((d.getWidth() / 3) + 18, d.getHeight() / 10 + 10, 215, 5);
        d.drawText((d.getWidth() / 3) + 20, d.getHeight() / 10, "High Scores", 40);
        d.setColor(new Color(0x4E4A0D));
        d.drawText(d.getWidth() / 5, d.getHeight() - 120, "Press SPACE to go Back", 40);
        d.setColor(Color.BLACK);
        d.drawText(widthName, height, "Player's Name", 30);
        d.drawText(widthScore, height, "Score", 30);
        d.fillRectangle(widthName, height + 5, 195, 3);
        d.fillRectangle(widthScore, height + 5, 80, 3);
        height += spaces;
        // draw all the scores.
        for (int i = 0; i < this.scores.size(); i++) {
            d.drawText(widthScore, height, Integer.toString(scores.getHighScores().get(i).getScore()), 30);
            d.drawText(widthName, height, (scores.getHighScores().get(i).getName()), 30);
            d.fillRectangle(widthName, height + 5, 500, 3);
            height += spaces;
        }
    }

    /**
     * determines when to stop the interfaces.Animation. if true the animation will stop,
     *
     * @return Boolean needToStop.
     */
    public boolean shouldStop() {
        return this.stopIt;
    }
}
