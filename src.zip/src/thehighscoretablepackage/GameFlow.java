/*
 * Yuval Levy
 * 205781966
 */
package thehighscoretablepackage;

import animation.EndScreen;
import gamelevels.GameLevel;

import java.io.File;
import java.io.IOException;
import java.util.List;

import biuoop.KeyboardSensor;
import interfaces.LevelInformation;
import animation.AnimationRunner;
import indicators.Counter;
import animation.KeyPressStoppableAnimation;
import biuoop.DialogManager;

/**
 * in charge of moving from one level to another.
 *
 * @ author: Yuval Levy
 */
public class GameFlow {
    //fields.
    private AnimationRunner ar;
    private KeyboardSensor ks;
    private Counter numOfLives;
    private Counter score;
    private HighScoresTable scoresTable;

    /**
     * Constructor.
     *
     * @param ar the animation that takes animation object and runs it.
     * @param ks the KeyboardSensor
     */
    public GameFlow(AnimationRunner ar, KeyboardSensor ks, HighScoresTable scoresTable) {
        this.ar = ar;
        this.ks = ks;
        this.numOfLives = new Counter(7);
        this.score = new Counter(0);
        this.scoresTable = scoresTable;

    }

    /**
     * this method creates each Level. if the player lost it stops, the player won, then move to the next level.
     *
     * @param levels List<interfaces.LevelInformation> - contains all the the levels of the Game.
     */
    public void runLevels(List<LevelInformation> levels) {
        // run all 4 levels,
        for (LevelInformation levelInfo : levels) {
            // create + initialize the gamelevel.
            GameLevel level = new GameLevel(this.ar, score, numOfLives, levelInfo);
            level.initialize();
            // running the animation as long as the players live and the block are not 0.
            while (level.getNumOfLives() > 0 && level.getNumOfBlocks() > 0) {
                level.playOneTurn();
            }
            // players lives = 0 then game over.
            if (numOfLives.getValue() == 0) {
                //checking if the player's score should be on the scoreTabke.
                if (this.scoresTable.getRank(this.score.getValue()) > 0) {
                    DialogManager dialog = this.ar.getGui().getDialogManager();
                    String name = dialog.showQuestionDialog("Name", "What's your name?", "");
                    // adding the player's name and his score to the table.
                    this.scoresTable.add(new ScoreInfo(name, this.score.getValue()));
                    try {
                        this.scoresTable.save(new File("highscores.txt"));
                    } catch (IOException e) {
                        System.out.println("Something happened while writing to 'highscores.txt' File");
                    }
                }
                EndScreen loseEndScreen = new EndScreen(true, ks, this.score.getValue());
                KeyPressStoppableAnimation loseEndScreenK = new KeyPressStoppableAnimation(ks, ks.SPACE_KEY,
                        loseEndScreen);
                this.ar.run(loseEndScreenK);
                // after pressing SPACE we create the highscores table.
                HighScoresAnimation highScoresAnimation = new HighScoresAnimation(scoresTable);
                KeyPressStoppableAnimation scoreAnimK =
                        new KeyPressStoppableAnimation(ks, "space", highScoresAnimation);
                this.ar.run(scoreAnimK);
                return;
            }
        }
        if (this.scoresTable.getRank(this.score.getValue()) > 0) {
            DialogManager dialog = this.ar.getGui().getDialogManager();
            String name = dialog.showQuestionDialog("Name", "What's your name?", "");
            this.scoresTable.add(new ScoreInfo(name, this.score.getValue()));
            try {
                this.scoresTable.save(new File("highscores.txt"));
            } catch (IOException e) {
                System.out.println("Something happened while writing to 'highscores.txt' File");
            }
        }
        EndScreen winEndScreen = new EndScreen(false, ks, this.score.getValue());
        KeyPressStoppableAnimation winEndScreenK = new KeyPressStoppableAnimation(ks, ks.SPACE_KEY, winEndScreen);
        this.ar.run(winEndScreenK);
        HighScoresAnimation highScoresAnimation = new HighScoresAnimation(scoresTable);
        KeyPressStoppableAnimation scoreAnimK =
        new KeyPressStoppableAnimation(ks,"space",highScoresAnimation);
        this.ar.run(scoreAnimK);
        return;
    }
}
