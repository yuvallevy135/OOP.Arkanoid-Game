/*
 * Yuval Levy
 * 205781966
 */

package geomrtyshapes;

import java.util.ArrayList;
import java.util.List;

/**
 * geomrtyshapes.Line describes geomrtyshapes.Line object. A geomrtyshapes.Line contain start, end Points,
 * if vertical, if horizontal.
 *
 * @ author: Yuval Levy
 */
public class Line {
    // members of line.
    private Point start;
    private Point end;
    private boolean isVertical;
    private boolean isHorizontal;

    /**
     * the constructor of geomrtyshapes.Line.
     *
     * @param start the start point of the line.
     * @param end   the end point of the line.
     */
    public Line(Point start, Point end) {
        this(start.getX(), start.getY(), end.getX(), end.getY());
    }

    /**
     * another constructor of geomrtyshapes.Line.
     *
     * @param x1 the x coordinate of the first point.
     * @param y1 the y coordinate of the first point
     * @param x2 the x coordinate of the second point
     * @param y2 the y coordinate of the second point
     */
    public Line(double x1, double y1, double x2, double y2) {
        if (x1 <= x2) {
            // decide that the smallest x will be the start point of the line.
            this.start = new Point(x1, y1);
            this.end = new Point(x2, y2);
        } else {
            this.start = new Point(x2, y2);
            this.end = new Point(x1, y1);
        }
        // checking if the line is vertical or horizontal or nor either.
        this.isVertical = (x1 == x2);
        this.isHorizontal = (y1 == y2);
    }

    /**
     * Return the length of the line.
     *
     * @return the the length.
     */
    public double length() {
        double length = start.distance(end);
        return length;
    }

    /**
     * Returns the middle point of the line.
     *
     * @return the middle point of the line.
     */
    public Point middle() {
        // if the start and end line are the same point, then we will return either start or end.
        if (this.getStart() == this.getEnd()) {
            return this.getStart();
        }
        // calculating the x and y coordinates of middle point.
        double middleX = (this.getStart().getX() + this.getEnd().getX()) / 2.0;
        double middleY = (this.getStart().getY() + this.getEnd().getY()) / 2.0;
        Point middle = new Point(middleX, middleY);
        // return middle point.
        return middle;
    }

    /**
     * the function returns the start point of the line.
     *
     * @return start ponint.
     */
    public Point getStart() {
        return start;
    }

    /**
     * the function returns the end point of the line..
     *
     * @return end point
     */
    public Point getEnd() {
        return end;
    }

    /**
     * the func return true or false if the line is vertical.
     *
     * @return the true if the line is vertical or false if not.
     */
    public boolean isVertical() {
        return isVertical;
    }

    /**
     * the func return true or false if the line is horizontal.
     *
     * @return the true if the line is horizontal or false if not.
     */
    public boolean isHorizontal() {
        return isHorizontal;
    }


    /**
     * the func return true or false if the 2 lines are intersecting.
     *
     * @param other a line.
     * @return true if 2 lines are intersecting or false if not.
     */
    public boolean isIntersecting(Line other) {
        return (null != this.intersectionWith(other));
    }

    /**
     * function returns the point intersection of 2 line. If there isnt - returns null..
     *
     * @param other a line.
     * @return intersection point if there is. Else null.
     */
    public Point intersectionWith(Line other) {
        double thisX1 = this.getStart().getX();
        double thisX2 = this.getEnd().getX();
        double thisY1 = this.getStart().getY();
        double thisY2 = this.getEnd().getY();
        double otherX1 = other.getStart().getX();
        double otherX2 = other.getEnd().getX();
        double otherY1 = other.getStart().getY();
        double otherY2 = other.getEnd().getY();
        // slope of "this" line.
        double thisSlope;
        // slope of "other" line.
        double otherSlope;
        // intersection point of Y axis and "this" line
        double b1;
        // intersection point of Y axis and "other" line
        double b2;
        // x coordinate of intersection point.
        double intersectionX;
        // y coordinate of intersection point.
        double intersectionY;
        Point intersectionP;
        // if two lines are the same lines - no intersection point - return null.
        if (this.getStart().equals(other.getStart()) && this.getEnd().equals(other.getEnd())) {
            return null;
        } else if (this.getStart().equals(this.getEnd()) && other.getStart().equals(other.getEnd())
                && (this.getStart().equals(other.getStart()))) {
            // if 2 lines are points and the same one - no intersection point - return null.
            return null;
        } else if (this.getStart().equals(this.getEnd()) && other.getStart().equals(other.getEnd())) {
            // if two lines are points but different - no intersection point - return null.
            return null;
        } else if (this.isVertical() && other.isVertical()) {
            //if two lines are verticals - no intersection point - return null.
            return null;
        } else if (this.isVertical() && (!other.isVertical() && !other.isVertical())) {
            // if "this" is vertical and "other" is reuglar.
            // calculate other slope.
            otherSlope = ((otherY2 - otherY1) / (otherX2 - otherX1));
            // calculate other line intersection point with Y axis
            b2 = otherY1 + ((-1) * otherSlope * otherX1);
            // x coordinate will be "this" line x coordinate.
            intersectionX = this.getStart().getX();
            // calculating y coordinate after finding the x coordinate and b2.
            intersectionY = otherSlope * intersectionX + b2;
        } else if (other.isVertical() && (!this.isVertical() && !this.isVertical())) {
            // if "this"line  is regular and "other" is vertical
            // calculating "this" line slope.
            thisSlope = ((thisY2 - thisY1) / (thisX2 - thisX1));
            // calculate this line intersection point with Y axis
            b1 = thisY1 + ((-1) * thisSlope * thisX1);
            // x coordinate will be "other" line x coordinate.
            intersectionX = other.getStart().getX();
            // calculating y coordinate after finding the x coordinate and b1.
            intersectionY = thisSlope * intersectionX + b1;
        } else if (this.isHorizontal() && other.isHorizontal()) {
            // if both lines horizontal - no intersection point - null.
            return null;
        } else if (this.isHorizontal() && (!other.isHorizontal() && !other.isVertical())) {
            // if "this" is horizontal and "other" is reuglar.
            // calculating other line slope.
            otherSlope = ((otherY2 - otherY1) / (otherX2 - otherX1));
            // calculate other line intersection point with Y axis
            b2 = otherY1 + ((-1) * otherSlope * otherX1);
            // y coordinate will be "this" line y coordinate.
            intersectionY = this.getStart().getY();
            // calculating x coordinate after finding the y coordinate and b2.
            intersectionX = (intersectionY - b2) / otherSlope;
        } else if (other.isHorizontal() && (!this.isHorizontal() && !this.isVertical())) {
            // if "this" is regular and "other" is horizontal
            // calculating this slope.
            thisSlope = ((thisY2 - thisY1) / (thisX2 - thisX1));
            // calculate this line intersection point with Y axis
            b1 = thisY1 + ((-1) * thisSlope * thisX1);
            // y coordinate will be "other" line y coordinate.
            intersectionY = other.getStart().getY();
            // calculating x coordinate after finding the y coordinate and b1.
            intersectionX = (intersectionY - b1) / thisSlope;
        } else if (this.isVertical() && other.isHorizontal()) {
            //this line is vertical and other is horizontal.
            // taking the x of this line, and y of other line.
            intersectionY = otherY1;
            intersectionX = thisX1;
        } else if (this.isHorizontal() && other.isVertical()) {
            //this line is horizontal and other is horizontal.
            // taking the x of this line, and y of other line.
            intersectionY = thisY1;
            intersectionX = otherX1;
        } else {
            // both line are regulars - finding the intersection point.
            // this line slope.
            thisSlope = ((thisY2 - thisY1) / (thisX2 - thisX1));
            // other line slope.
            otherSlope = ((otherY2 - otherY1) / (otherX2 - otherX1));
            // this line intersection with Y axis.
            b1 = (thisY1 + ((-1) * thisSlope * thisX1));
            // other line intersection with Y axis.
            b2 = (otherY1 + ((-1) * otherSlope * otherX1));
            // calculating the intersectionX.
            intersectionX = (b2 - b1) / (thisSlope - otherSlope);
            // calculating the intersectionX.
            intersectionY = (thisSlope * intersectionX) + b1;
        }
        intersectionP = new Point(intersectionX, intersectionY);
        // checking if the intersection point is on both lines.
        if ((this.isPointOnLine(intersectionP)) && (other.isPointOnLine(intersectionP))) {
            // the intersection point is on both lines - return the point.
            return intersectionP;
        } else {
            // the intersection point isnt on both lines - return null.
            return null;
        }
    }

    /**
     * function returns true if a point is on a line.
     *
     * @param point a point.
     * @return true if a point is on a line. else false.
     */
    public boolean isPointOnLine(Point point) {
        return (((point.getX() >= this.getStart().getX()) && (point.getX() <= this.getEnd().getX()))
                && ((point.getY() >= this.getStart().getY() && point.getY() <= this.getEnd().getY())
                || (point.getY() <= this.getStart().getY() && point.getY() >= this.getEnd().getY())));
    }

    /**
     * function returns true if two lines are equal. else false..
     *
     * @param other other line.
     * @return true or false if 2 lines are equal
     */
    public boolean equals(Line other) {
        return this.start.equals(other.getStart()) && this.end.equals(other.getEnd());
    }

    /**
     * if a line intersects with the rectangle, it will return the closest intersection point. else it will return null.
     *
     * @param rect the rectangle we want to check intersection with.
     * @return the closest intersection point or null.
     */

    public Point closestIntersectionToStartOfLine(Rectangle rect) {
        List<Point> intersectionPointList = new ArrayList<Point>();
        // the list will have all the intersection point of the line with the rectangle.
        intersectionPointList = rect.intersectionPoints(this);
        // potential intersection point.
        Point closestIntersectionPoint;
        double closestDistance;
        // if there are no points - null
        if (intersectionPointList.isEmpty()) {
            return null;
        } else {
            // getting the distance from the start point of the line and the first intersection point;
            closestDistance = this.getStart().distance(intersectionPointList.get(0));
            // creating the closest intersection point.
            closestIntersectionPoint = new Point(intersectionPointList.get(0).getX(),
                    intersectionPointList.get(0).getY());
            // we will check all of the intersection points and get the closest.
            for (int i = 0; i < intersectionPointList.size(); i++) {
                //checking which point has the smallest distance from the start point of the rect.
                if (this.getStart().distance(intersectionPointList.get(i)) < closestDistance) {
                    // setting the new distance.
                    closestDistance = this.getStart().distance(intersectionPointList.get(i));
                    // setting the new clost point.
                    closestIntersectionPoint = new Point(intersectionPointList.get(i).getX(),
                            intersectionPointList.get(i).getY());
                }
            }
        }
        return closestIntersectionPoint;
    }
}

