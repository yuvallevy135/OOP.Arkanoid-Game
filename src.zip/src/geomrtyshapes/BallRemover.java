/*
 * Yuval Levy
 * 205781966
 */

package geomrtyshapes;

import paddleandblock.Block;
import indicators.Counter;
import interfaces.HitListener;
import gamelevels.GameLevel;

/**
 * a geomrtyshapes.BallRemover in charge of removing all the balls from the game, and keep tracking on the num of
 * balls that remained in the game.
 *
 * @ author: Yuval Levy
 */
public class BallRemover implements HitListener {
    // field.
    private GameLevel game;
    private Counter remainingBalls;

    /**
     * Constructor.
     *
     * @param game           the game that we want to remove balls from.
     * @param remainingBalls a counter that tells us the num of balls that left in the game.
     */
    public BallRemover(GameLevel game, Counter remainingBalls) {
        this.game = game;
        this.remainingBalls = remainingBalls;
    }

    /**
     * calls this func when the beingHit object is being hit.
     * the hitter is a ball whos doing the hit.
     *
     * @param beingHit the paddleandblock.Block that was involved in the hit
     * @param hitter   the geomrtyshapes.Ball that was involved in the hit
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        hitter.removeFromGame(this.game);
        this.remainingBalls.decrease(1);
    }
}
