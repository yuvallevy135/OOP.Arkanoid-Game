/*
 * Yuval Levy
 * 205781966
 */

package geomrtyshapes;
/**
 * geomrtyshapes.Point describes geomrtyshapes.Point object. A point contains x,y coordinates.
 *
 * @ author: Yuval Levy
 */
public class Point {
    // members of the point.
    private double x;
    private double y;

    /**
     * constructor of the point.
     *
     * @param x the x coordinate
     * @param y the y coordinate
     */
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    /**
     * the function calculates the distance between 2 points..
     *
     * @param other the other - geomrtyshapes.Point.
     * @return the distance between 2 points.
     */
    public double distance(Point other) {
        double thisX1 = this.getX();
        double thisY1 = this.getY();
        double otherX2 = other.getX();
        double otherY2 = other.getY();
        // gets the distance ^ 2 of 2 points.
        double distance = Math.sqrt(((otherY2 - thisY1) * (otherY2 - thisY1))
                + ((otherX2 - thisX1) * (otherX2 - thisX1)));
        // return the exact distance between 2 points.
        return distance;
    }

    /**
     * check if 2 points are equal or not.
     *
     * @param other a point.
     * @return the true if the points are equal, or false if not.
     */

    public boolean equals(Point other) {
        return (this.getX() == other.getX()) && (this.getY() == other.getY());
    }

    /**
     * return the x coordinate of the point.
     *
     * @return the x
     */
    public double getX() {
        return x;
    }

    /**
     * return the y coordinate of the point.
     *
     * @return the y
     */
    public double getY() {
        return y;
    }
}