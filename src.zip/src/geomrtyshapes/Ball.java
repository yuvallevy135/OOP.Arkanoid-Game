/*
 * Yuval Levy
 * 205781966
 */

package geomrtyshapes;

import java.awt.Color;

import interfaces.Sprite;
import biuoop.DrawSurface;
import gamelevels.GameEnvironment;
import gamelevels.GameLevel;


/**
 * geomrtyshapes.Ball describes geomrtyshapes.Ball object. geomrtyshapes.Ball contains its center geomrtyshapes.Point,
 * radius,color and also the screen coordinates points.
 *
 * @ author: Yuval Yuval
 */
public class Ball implements Sprite {
    // the center of the ball
    private Point center;
    // the radius
    private int r;
    // the ball's color.
    private Color color;
    // the velocity of the ball.
    private Velocity v;
    // border of the screen for the ball.
    private Point startScreen;
    private Point endScreen;
    private GameEnvironment gameEnvironment;

    /**
     * constructor of geomrtyshapes.Ball..
     *
     * @param center the center point of the ball
     * @param r      the radius
     * @param color  the color
     */
    public Ball(Point center, int r, java.awt.Color color) {
        this.center = center;
        this.r = r;
        this.color = color;
    }

    /**
     * second constructor of geomrtyshapes.Ball.
     *
     * @param center      the center
     * @param r           the radius
     * @param color       the color
     * @param startScreen the start screen
     * @param endScreen   the end screen
     */
    public Ball(Point center, int r, java.awt.Color color, Point startScreen, Point endScreen) {
        this.center = center;
        this.r = r;
        this.color = color;
        this.startScreen = startScreen;
        this.endScreen = endScreen;
    }

    /**
     * third constructor of geomrtyshapes.Ball.
     *
     * @param center          the center
     * @param radius          the radius
     * @param color           the color
     * @param gameEnvironment the game environment
     */
    public Ball(Point center, int radius, java.awt.Color color, GameEnvironment gameEnvironment) {
        this.center = center;
        this.r = radius;
        this.color = color;
        this.gameEnvironment = gameEnvironment;
    }

    /**
     * Set game environment.
     *
     * @param setGameEnvironment the game environment
     */
    public void setGameEnvironment(GameEnvironment setGameEnvironment) {
        this.gameEnvironment = setGameEnvironment;
    }

    /**
     * Gets x coordinate of the ball.
     *
     * @return the x coordinate.
     */
    public int getX() {
        return (int) this.center.getX();
    }

    /**
     * Gets y coordinate of the ball.
     *
     * @return the y coordinate.
     */
    public int getY() {
        return (int) this.center.getY();
    }

    /**
     * Gets the radius of the ball.
     *
     * @return the radius.
     */
    public int getSize() {
        return this.r;
    }

    /**
     * Gets color.
     *
     * @return the color
     */
    public java.awt.Color getColor() {
        return this.color;
    }

    /**
     * Sets velocity of the ball.
     *
     * @param velocity the velocity
     */
    public void setVelocity(Velocity velocity) {
        this.v = velocity;
    }

    /**
     * return the start screen point of where the ball can be.
     *
     * @return the start screen point
     */
    public Point startScreen() {
        return startScreen;

    }

    /**
     * return the end screen point of where the ball can be.
     *
     * @return the end screen point
     */
    public Point endScreen() {
        return endScreen;
    }

    /**
     * another way to set the velocity of the ball.
     *
     * @param dx the movement in x axle
     * @param dy the movement in y axle
     */
    public void setVelocity(double dx, double dy) {
        this.v = new Velocity(dx, dy);
    }

    /**
     * Gets velocity of the ball.
     *
     * @return the velocity
     */
    public Velocity getVelocity() {
        return this.v;
    }

    /**
     * this function is responsible of the moving ball inside the animation. if the ball doesn't touch any object
     * it will move in its current velocity. Otherwise there will be a collision point and we will get the ball
     * closer to the object that it touched and change the ball's velocity accordingly.
     */
    public void moveOneStep() {
        double oldXvelocity = this.getVelocity().getDx();
        double oldYvelocity = this.getVelocity().getDy();
        double newXofPoint = this.center.getX();
        double newYofPoint = this.center.getY();
        // creating a line trajectory to check the course movement of the ball.
        Line trajectory = new Line(this.center, this.getVelocity().applyToPoint(this.center));
        // getting info about the closest colliding point if there is one.
        CollisionInfo collidingPointInfo = this.gameEnvironment.getClosestCollision(trajectory);
        // if we didn't find any collision - move the ball.
        if (collidingPointInfo == null) {
            // we can move the ball.
            this.center = this.getVelocity().applyToPoint(this.center);
        } else {
            // there was a hit.
            // set the ball's new velocity.
            this.setVelocity(collidingPointInfo.collisionObject()
                    .hit(this, collidingPointInfo.collisionPoint(), getVelocity()));
            if (this.getVelocity().getDy() != oldYvelocity) {
                // If the ball's Y velocity changed we check what was the old velocity and get the ball closer to
                // the object that it touched.
                if (oldYvelocity > 0) {
                    newYofPoint = collidingPointInfo.collisionPoint().getY() - this.r;
                } else {
                    newYofPoint = collidingPointInfo.collisionPoint().getY() + this.r;
                }
            }
            if (this.getVelocity().getDx() != oldXvelocity) {
                // If the ball's X velocity changed we check what was the old velocity and get the ball closer to
                // the object that it touched.
                if (oldXvelocity > 0) {
                    newXofPoint = collidingPointInfo.collisionPoint().getX() - this.r;
                } else {
                    newXofPoint = collidingPointInfo.collisionPoint().getX() + this.r;
                }
            }
            // at the end we move the ball with it's new x and y coordinates.
            this.center = new Point(newXofPoint, newYofPoint);
        }
    }

    /**
     * draw the ball on the given DrawSurface.
     *
     * @param surface the surface
     */
    public void drawOn(DrawSurface surface) {
        // setting the color.
        surface.setColor(this.color);
        // filling the circle which is the ball with color.
        surface.fillCircle(this.getX(), this.getY(), this.r);
        surface.setColor(Color.BLACK);
        // draw it on the surface.
        surface.drawCircle(this.getX(), this.getY(), this.r);
    }

    /**
     * notify the ball that time has passed and it should make a new movement.
     */
    public void timePassed() {
        this.moveOneStep();
    }

    /**
     * Add to game.
     *
     * @param g the game that we want to add the ball to.
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }

    /**
     * Remove from game.
     *
     * @param game the game
     */
    public void removeFromGame(GameLevel game) {
        game.removeSprite(this);
    }
}