/*
 * Yuval Levy
 * 205781966
 */

package geomrtyshapes;

import java.util.ArrayList;
import java.util.List;

/**
 * a geomrtyshapes.Rectangle objet. It has upperLeft point, width and height.
 *
 * @ author: Yuval Levy
 */
public class Rectangle {
    // the upper left point of the rectangle - the start point.
    private Point upperLeft;
    // the width of the rectangle.
    private double width;
    // the height of the ractangle.
    private double height;

    /**
     * Instantiates a new geomrtyshapes.Rectangle.
     *
     * @param upperLeft the upper left point of the rect.
     * @param width     the width
     * @param height    the height
     */
    public Rectangle(Point upperLeft, double width, double height) {
        this.upperLeft = upperLeft;
        this.width = width;
        this.height = height;
    }

    /**
     * the func gets a line and and checks if there was an intersection with the rectangle sides.
     * the func will return a list of intersection points.
     *
     * @param line the line we want to check if intersects with the rectangle
     * @return a list of intersection points. It can be empty.
     */

    public java.util.List<Point> intersectionPoints(Line line) {
        // get the sides of the rectangle.
        Line upperLine = new Line(this.getUpperLeft(), this.getUpperRight());
        Line lowerLine = new Line(this.getLowerLeft(), this.getLowerRight());
        Line leftLine = new Line(this.getUpperLeft(), this.getLowerLeft());
        Line rightLine = new Line(this.getUpperRight(), this.getLowerRight());
        // the list will contain all the intersection point.
        List<Point> intersectionPointList = new ArrayList<Point>();
        // check if the the given line intersect with any of the rectangle's sides.
        if (upperLine.isIntersecting(line)) {
            intersectionPointList.add(upperLine.intersectionWith(line));
        }
        if (lowerLine.isIntersecting(line)) {
            intersectionPointList.add(lowerLine.intersectionWith(line));
        }
        if (leftLine.isIntersecting(line)) {
            intersectionPointList.add(leftLine.intersectionWith(line));
        }
        if (rightLine.isIntersecting(line)) {
            intersectionPointList.add(rightLine.intersectionWith(line));
        }
        return intersectionPointList;
    }

    /**
     * Gets width.
     *
     * @return the width of the rectangle.
     */
    public double getWidth() {
        return this.width;
    }

    /**
     * Gets height.
     *
     * @return the height of the rectangle.
     */
    public double getHeight() {
        return this.height;
    }

    /**
     * Gets upper left.
     *
     * @return the upper left point of the rectangle.
     */
    public Point getUpperLeft() {
        return this.upperLeft;
    }

    /**
     * Gets lower left.
     *
     * @return the lower left point of the rectangle.
     */
    public Point getLowerLeft() {
        Point lowerLeft = new Point(this.getUpperLeft().getX(), this.getUpperLeft().getY() + this.getHeight());
        return lowerLeft;
    }

    /**
     * Gets upper right.
     *
     * @return the upper right point of the rectangle.
     */
    public Point getUpperRight() {
        Point upperRight = new Point(this.getUpperLeft().getX() + this.getWidth(), this.getUpperLeft().getY());
        return upperRight;
    }

    /**
     * Gets lower right.
     *
     * @return the lower right point of the rectangle.
     */
    public Point getLowerRight() {
        Point lowerRight = new Point(this.getUpperLeft().getX() + this.getWidth(),
                this.getUpperLeft().getY() + this.getHeight());
        return lowerRight;
    }

    /**
     * Gets upper line.
     *
     * @return the upper line of the rectangle.
     */
    public Line getUpperLine() {
        Line upperLine = new Line(this.getUpperLeft(), this.getUpperRight());
        return upperLine;
    }

    /**
     * Gets left line.
     *
     * @return the left line of the rectangle.
     */
    public Line getLeftLine() {
        Line leftLine = new Line(this.getUpperLeft(), this.getLowerLeft());
        return leftLine;
    }

    /**
     * Gets lower line.
     *
     * @return the lower line of the rectangle.
     */
    public Line getLowerLine() {
        Line lowerline = new Line(this.getLowerLeft(), this.getLowerRight());
        return lowerline;
    }

    /**
     * Gets right line.
     *
     * @return the right line of the rectangle.
     */
    public Line getRightLine() {
        Line rightLine = new Line(this.getUpperRight(), this.getLowerRight());
        return rightLine;
    }

    /**
     * Sets new upper left point of the rectangle.
     *
     * @param newUpperLeftP the new upper left point of the rectangle.
     */
    public void setNewUpperLeftP(Point newUpperLeftP) {
        this.upperLeft = newUpperLeftP;
    }
}
