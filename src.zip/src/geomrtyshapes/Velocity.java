/*
 * Yuval Levy
 * 205781966
 */

package geomrtyshapes;

/**
 * geomrtyshapes.Velocity specifies the change in position on the x and the y axes.
 *
 * @ author: Yuval Levy
 */
public class Velocity {
    private double dx;
    private double dy;

    /**
     * constructor.
     *
     * @param dx the dx
     * @param dy the dy
     */
    public Velocity(double dx, double dy) {
        this.dx = dx;
        this.dy = dy;
    }

    /**
     * Gets dx.
     *
     * @return the dx
     */
    public double getDx() {
        return this.dx;
    }

    /**
     * Gets dy.
     *
     * @return the dy
     */
    public double getDy() {
        return this.dy;
    }

    /**
     * defining the velocity in terms of speed and angle instead of dx, dy.
     *
     * @param angle the angle
     * @param speed the speed
     * @return the velocity
     */
    public static Velocity fromAngleAndSpeed(double angle, double speed) {
        angle = Math.toRadians(angle);
        double dx = Math.sin(angle) * (speed);
        double dy = -Math.cos(angle) * (speed);
        return new Velocity(dx, dy);
    }

    /**
     * The function takes a point with position (x,y) and returns a new point with position (x+dx, y+dy).
     *
     * @param p the point
     * @return the point
     */
    public Point applyToPoint(Point p) {
        // if point isnt set - means null.
        if (p == null) {
            return null;
        } else {
            // get the new coordinates.
            double newX = this.dx + p.getX();
            double newY = this.dy + p.getY();
            Point newPoint = new Point(newX, newY);
            // return the new point.
            return newPoint;
        }
    }

    /**
     * Sets dx.
     *
     * @param newDx the dx
     */
    public void setDx(double newDx) {
        this.dx = newDx;
    }

    /**
     * Sets dy.
     *
     * @param newDy the dy
     */
    public void setDy(double newDy) {
        this.dy = newDy;
    }
}