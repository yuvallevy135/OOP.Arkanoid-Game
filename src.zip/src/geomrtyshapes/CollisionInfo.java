/*
 * Yuval Levy
 * 205781966
 */

package geomrtyshapes;

import geomrtyshapes.Point;
import interfaces.Collidable;


/**
 * The object has a geomrtyshapes.Point and a interfaces.Collidable. if there was a collision with an other object,
 * and a collidable, the point contains the collision point. the interfaces.Collidable contains the collidable that
 * collided with the ball.
 *
 * @ author: Yuval Levy
 */
public class CollisionInfo {

    //fields.
    private Point collisionPoint;
    private Collidable collisionObject;

    /**
     * constructor.
     *
     * @param collisionPoint  the collision point
     * @param collisionObject the collision object
     */
    public CollisionInfo(Point collisionPoint, Collidable collisionObject) {
        this.collisionPoint = collisionPoint;
        this.collisionObject = collisionObject;
    }

    /**
     * the func returns the collision point.
     *
     * @return the collision point
     */
    public Point collisionPoint() {
        return this.collisionPoint;
    }

    /**
     * the func return a collidable  object that was involved.
     *
     * @return the collidable
     */
    public Collidable collisionObject() {
        return this.collisionObject;
    }
}