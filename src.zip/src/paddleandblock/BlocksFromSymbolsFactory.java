/*
 * Yuval Levy
 * 205781966
 */
package paddleandblock;

import interfaces.BlockCreator;

import java.util.Map;


/**
 * getting a symbol and then check if its a block or space.
 */
public class BlocksFromSymbolsFactory {
    private Map<String, Integer> spacerWidths;
    private Map<String, BlockCreator> blockCreators;


    /**
     * constructor.
     *
     * @param spacerWidths  map of the spacers - sdef.
     * @param blockCreators map of the block - bdef.
     */
    public BlocksFromSymbolsFactory(Map<String, Integer> spacerWidths, Map<String, BlockCreator> blockCreators) {
        this.spacerWidths = spacerWidths;
        this.blockCreators = blockCreators;
    }

    /**
     * return is 's' is in did a valid space.
     *
     * @param s the s
     * @return the boolean
     */
    public boolean isSpaceSymbol(String s) {
        return this.spacerWidths.containsKey(s);
    }

    /**
     * return is 's' is in did a block symbol.
     *
     * @param s the s
     * @return the boolean
     */
    public boolean isBlockSymbol(String s) {
        return this.blockCreators.containsKey(s);
    }

    /**
     * return a block according to the def
     * the block will be in (xpos,ypos).
     *
     * @param s    the letter.
     * @param xPos the x pos.
     * @param yPos the y pos
     * @return the block
     */
    public Block getBlock(String s, int xPos, int yPos) {
        return this.blockCreators.get(s).create(xPos, yPos);
    }

    /**
     * return the width in pixel of the given spacer.
     *
     * @param s the letter.
     * @return the spacer width int.
     */
    public int getSpaceWidth(String s) {
        return this.spacerWidths.get(s);
    }
}
