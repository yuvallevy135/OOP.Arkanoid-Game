/*
 * Yuval Levy
 * 205781966
 */


package paddleandblock;

import gamelevels.GameLevel;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import geomrtyshapes.Ball;
import geomrtyshapes.Point;
import geomrtyshapes.Rectangle;
import geomrtyshapes.Velocity;
import interfaces.Collidable;
import interfaces.Sprite;

import java.awt.Color;

/**
 * The paddleandblock.Paddle is the player. it is a rectangle with implements interfaces.Sprite,
 * interfaces.Collidable. can move left or right.
 *
 * @ author: Yuval Levy
 */
public class Paddle implements Sprite, Collidable {
    private biuoop.KeyboardSensor keyboard;
    private Color color;
    private Rectangle rectangle;
    private double velocity;
    private double rightBorder;
    private double leftBorder;

    /**
     * constructor of the paddleandblock.Paddle.
     *
     * @param keyboard    reading the keys from keyboard
     * @param color       the color
     * @param rectangle   the rectangle that describes the paddle
     * @param velocity    the velocity
     * @param leftBorder  the X coordinate which the paddle cant pass from left.
     * @param rightBorder the X coordinate which the paddle cant pass from right.
     */
    public Paddle(KeyboardSensor keyboard, Color color, Rectangle rectangle, double velocity,
                  double leftBorder, double rightBorder) {
        this.keyboard = keyboard;
        this.color = color;
        this.rectangle = new Rectangle(new Point(rectangle.getUpperLeft().getX(), rectangle.getUpperLeft().getY()),
                rectangle.getWidth(), rectangle.getHeight());
        this.velocity = velocity;
        this.rightBorder = rightBorder;
        this.leftBorder = leftBorder;

    }


    /**
     * Move the paddle to the left.
     */
    public void moveLeft() {
        Point newUpperLeftP;
        // if there was a press on the LEFT key.
        if (keyboard.isPressed(KeyboardSensor.LEFT_KEY)) {
            // making sure the paddle wont pass the border.
            if (this.rectangle.getUpperLeft().getX() - this.velocity < this.leftBorder) {
                // the upper left point of the paddle will be MAX the left border x.
                newUpperLeftP = new Point(this.leftBorder, this.rectangle.getUpperLeft().getY());
                this.rectangle.setNewUpperLeftP(newUpperLeftP);
            } else {
                // the paddle is approved to move.
                newUpperLeftP = new Point(this.rectangle.getUpperLeft().getX() - velocity,
                        this.rectangle.getUpperLeft().getY());
                this.rectangle.setNewUpperLeftP(newUpperLeftP);
            }
        }
    }

    /**
     * Move the paddle to the right.
     */
    public void moveRight() {
        Point newUpperRightP;
        // if there was a press on the RIGHT key.
        if (keyboard.isPressed(KeyboardSensor.RIGHT_KEY)) {
            // making sure the paddle wont pass the border.
            if (this.rectangle.getUpperRight().getX() + this.velocity > this.rightBorder) {
                // the upper right point of the paddle will be MAX the right border x.
                newUpperRightP = new Point(this.rightBorder - this.rectangle.getWidth(),
                        this.rectangle.getUpperLeft().getY());
                this.rectangle.setNewUpperLeftP(newUpperRightP);
            } else {
                // the paddle is approved to move.
                newUpperRightP = new Point(this.rectangle.getUpperLeft().getX() + velocity,
                        this.rectangle.getUpperLeft().getY());
                this.rectangle.setNewUpperLeftP(newUpperRightP);
            }
        }
    }

    /**
     * if time passed - see if moving is required.
     */
    public void timePassed() {
        this.moveLeft();
        this.moveRight();
    }

    /**
     * drawing the paddle and its lines.
     *
     * @param d - the DrawSurface of the GUI of the gamelevels.Game create.
     */
    public void drawOn(DrawSurface d) {
        d.setColor(this.color);
        d.fillRectangle((int) this.rectangle.getUpperLeft().getX(), (int) this.rectangle.getUpperLeft().getY(),
                (int) this.rectangle.getWidth(), (int) this.rectangle.getHeight());
        d.setColor(Color.BLACK);
        d.drawRectangle((int) this.rectangle.getUpperLeft().getX(), (int) this.rectangle.getUpperLeft().getY(),
                (int) this.rectangle.getWidth(), (int) this.rectangle.getHeight());
    }

    /**
     * returning the rectangle when there was a collision.
     *
     * @return - geomrtyshapes.Rectangle this.rectangle
     */
    public Rectangle getCollisionRectangle() {
        return this.rectangle;
    }

    /**
     * if there was a collision of an object with this paddleandblock.Paddle, the function returns the new
     * velocity of the colliding object after the hit.
     *
     * @param hitter          - the ball that hit.
     * @param collisionPoint  geomrtyshapes.Point that describes the collision point.
     * @param currentVelocity - the current velocity of the colliding object.
     * @return newVelocity - the new velocity of the geomrtyshapes.Ball.
     */
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        // a fifth of the paddle width
        double fifthPaddle = (this.rectangle.getWidth() / 5);
        //speed of the ball.
        double speed = Math.sqrt(Math.pow(currentVelocity.getDx(), 2) + Math.pow(currentVelocity.getDy(), 2));
        // new velocity.
        Velocity newVelocity = new Velocity(currentVelocity.getDx(), currentVelocity.getDy());
        // if the ball hits the first fifth of the paddle.
        if (collisionPoint.getX() <= (this.rectangle.getUpperLeft().getX() + fifthPaddle)) {
            newVelocity = Velocity.fromAngleAndSpeed(300, speed);
            //if the bll hits the second fifth of the paddle.
        } else if ((collisionPoint.getX() > (this.rectangle.getUpperLeft().getX() + fifthPaddle))
                && (collisionPoint.getX() <= (this.rectangle.getUpperLeft().getX() + (2 * fifthPaddle)))) {
            newVelocity = Velocity.fromAngleAndSpeed(330, speed);
            // if the ball hits the third fifth of the paddle.
        } else if ((collisionPoint.getX() > (this.rectangle.getUpperLeft().getX() + (2 * fifthPaddle)))
                && (collisionPoint.getX() <= (this.rectangle.getUpperLeft().getX() + (3 * fifthPaddle)))) {
            // only change vertical.
            newVelocity = new Velocity(currentVelocity.getDx(), (currentVelocity.getDy() * (-1)));
            // if the ball hits the forth fifth of the paddle.
        } else if ((collisionPoint.getX() > (this.rectangle.getUpperLeft().getX() + (3 * fifthPaddle)))
                && (collisionPoint.getX() <= (this.rectangle.getUpperLeft().getX() + (4 * fifthPaddle)))) {
            newVelocity = Velocity.fromAngleAndSpeed(30, speed);
            // if the ball hits the last fifth of the paddle.
        } else if ((collisionPoint.getX() > (this.rectangle.getUpperLeft().getX() + (4 * fifthPaddle)))
                && (collisionPoint.getX() <= (this.rectangle.getUpperLeft().getX() + (5 * fifthPaddle)))) {
            newVelocity = Velocity.fromAngleAndSpeed(60, speed);
        }
        return newVelocity;
    }

    /**
     * Add the paddle to the game.
     *
     * @param g the g
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
        g.addCollidable(this);
    }

    /**
     * Remove Paddle from game.
     *
     * @param game the game
     */
    public void removeFromGame(GameLevel game) {
        game.removeSprite(this);
        game.removeCollidable(this);
    }
}