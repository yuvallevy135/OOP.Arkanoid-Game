/*
 * Yuval Levy
 * 205781966
 */

package paddleandblock;

import gamelevels.GameLevel;
import biuoop.DrawSurface;
import geomrtyshapes.Ball;
import geomrtyshapes.Line;
import geomrtyshapes.Point;
import geomrtyshapes.Rectangle;
import interfaces.Collidable;
import interfaces.HitListener;
import interfaces.HitNotifier;
import interfaces.Sprite;
import geomrtyshapes.Velocity;

import java.util.ArrayList;
import java.util.List;
import java.awt.Color;
import java.awt.Image;
import java.util.Map;

/**
 * The block is an obstacle on the screen, initialized  with a rectangle, color and blocklife.
 * Implements interfaces.Collidable and interfaces.Sprite. If a ball hits a block its will change it's velocity.
 *
 * @ author: Yuval Levy
 */


public class Block implements Collidable, Sprite, HitNotifier {

    //the fields of the block.
    private Rectangle rectangle;
    private Color color;
    private int blockLife;
    private List<HitListener> hitListeners;
    private Map<Integer, Color> colorMap;
    private Map<Integer, Image> imageMap;
    private Color stroke;

    /**
     * constructor .
     *
     * @param rectangle block will be a rectangle
     * @param color     has a color.
     * @param blockLife each block has a "life". Every time a ball hits a block, the block life decreases by 1 until
     *                  it reaches 0. The block life will be shown on the block it self until reaches 0 which is "X"
     */
    public Block(Rectangle rectangle, Color color, int blockLife) {
        this.rectangle = rectangle;
        this.color = color;
        this.blockLife = blockLife;
        this.hitListeners = new ArrayList<HitListener>();
    }

    public Block(Rectangle rectangle, Map<Integer, Image> imageMap, Map<Integer, Color> colorMap, int blockLife) {
        this.rectangle = rectangle;
        this.imageMap = imageMap;
        this.colorMap = colorMap;
        this.blockLife = blockLife;
        this.hitListeners = new ArrayList<HitListener>();
    }

    public Block(Rectangle rectangle, Color color) {
        this.rectangle = rectangle;
        this.color = color;
        this.blockLife = 1;
        this.hitListeners = new ArrayList<HitListener>();
    }
    public double getWidth(){
        return this.rectangle.getWidth();
    }

    public void addStorkeToBlock(Color strokeColor) {
        this.stroke = strokeColor;
    }

    /**
     * returns the shape (rectangle) of the block.
     *
     * @return geomrtyshapes.Rectangle this.rectangle
     */
    public Rectangle getCollisionRectangle() {
        return this.rectangle;
    }

    /**
     * Gets block life.
     *
     * @return the block life
     */
    public int getHitPoints() {
        return blockLife;
    }

    /**
     * if there was a collision of an object with a block, the func will return a new velocity of the object that
     * was colliding with the block after the hit.
     *
     * @param hitter          - the ball that hit.
     * @param collisionPoint  geomrtyshapes.Point that describes the collision point.
     * @param currentVelocity geomrtyshapes.Velocity - the current velocity of the colliding object.
     * @return the velocity after the collision
     */
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        // of the rectangle.
        Line upperLine = this.rectangle.getUpperLine();
        Line lowerLine = this.rectangle.getLowerLine();
        Line rightLine = this.rectangle.getRightLine();
        Line leftLine = this.rectangle.getLeftLine();
        // because there was a hit we need to decrease the block life by 1 if it's not 0.
        if (this.blockLife > 0) {
            this.blockLife--;
        }
        // create a new velocity to return.
        Velocity newVelocity = currentVelocity;
        // if there was a hit in the upper or the lower line, we change the vertical velocity.
        if (upperLine.isPointOnLine(collisionPoint) || (lowerLine.isPointOnLine(collisionPoint))) {
            newVelocity = new Velocity(currentVelocity.getDx(), currentVelocity.getDy() * (-1));
        }
        // if there was a hit in the left or the right line, we change the horizontal velocity.
        if (rightLine.isPointOnLine(collisionPoint) || leftLine.isPointOnLine(collisionPoint)) {
            newVelocity = new Velocity(currentVelocity.getDx() * (-1), currentVelocity.getDy());
        }
        this.notifyHit(hitter);
        return newVelocity;
    }

    /**
     * this function draws this block.
     *
     * @param surface - the surface we draw on
     */
    public void drawOn(DrawSurface surface) {
        if (imageMap != null && imageMap.containsKey(blockLife)) {
            Image rectangleImage = imageMap.get(blockLife);
            surface.drawImage((int) this.rectangle.getUpperLeft().getX(),
                    (int) this.rectangle.getUpperLeft().getY(), rectangleImage);
        } else if (colorMap != null && colorMap.containsKey(blockLife)) {
            Color fillColor = colorMap.get(blockLife);
            surface.setColor(fillColor);
            surface.fillRectangle((int) this.rectangle.getUpperLeft().getX(),
                    (int) this.rectangle.getUpperLeft().getY(),
                    (int) this.rectangle.getWidth(), (int) this.rectangle.getHeight());
            if (stroke != null) {
                surface.setColor(stroke);
            }
            surface.drawRectangle((int) this.rectangle.getUpperLeft().getX(),
                    (int) this.rectangle.getUpperLeft().getY(),
                    (int) this.rectangle.getWidth(),
                    (int) this.rectangle.getHeight());
        } else {
            if (colorMap != null && colorMap.containsKey(1)) {
                Color fillColor = colorMap.get(1);
                surface.setColor(fillColor);
                surface.fillRectangle((int) this.rectangle.getUpperLeft().getX(),
                        (int) this.rectangle.getUpperLeft().getY(),
                        (int) this.rectangle.getWidth(), (int) this.rectangle.getHeight());
                surface.setColor(Color.BLACK);
                // draw it on the surface.
                surface.drawRectangle((int) this.rectangle.getUpperLeft().getX(),
                        (int) this.rectangle.getUpperLeft().getY(),
                        (int) this.rectangle.getWidth(), (int) this.rectangle.getHeight());
            } else if (imageMap != null && imageMap.containsKey(1)) {
                Image rectangleImage = imageMap.get(1);
                surface.drawImage((int) this.rectangle.getUpperLeft().getX(),
                        (int) this.rectangle.getUpperLeft().getY(), rectangleImage);
            } else {
                surface.setColor(this.color);
                surface.fillRectangle((int) this.rectangle.getUpperLeft().getX(),
                        (int) this.rectangle.getUpperLeft().getY(),
                        (int) this.rectangle.getWidth(), (int) this.rectangle.getHeight());
            }
        }

    }

    /**
     * tells the block the time has passed.
     */
    public void timePassed() {
    }

    /**
     * Add the block to this game.
     *
     * @param g the game we want to add the block to.
     */
    public void addToGame(GameLevel g) {
        g.addCollidable(this);
        g.addSprite(this);
    }

    /**
     * Remove from collidableandsprites.block from the list of all the sprites and collidables at the game.
     *
     * @param game the game that we want to remove the collidableandsprites.block from.
     */
    public void removeFromGame(GameLevel game) {
        game.removeCollidable(this);
        game.removeSprite(this);
    }

    /**
     * Add a  collidableandsprites.block to the hitlisteners list.
     *
     * @param hl - nitified of hit events.
     */
    public void addHitListener(HitListener hl) {
        this.hitListeners.add(hl);
    }

    /**
     * Remove a  collidableandsprites.block from the hitlisteners list.
     *
     * @param hl - nitified of hit events.
     */
    public void removeHitListener(HitListener hl) {
        this.hitListeners.remove(hl);

    }

    /**
     * we will use this func when a it happens and notified all who is registers in the interfaces.Hitlistener
     * and call thier hitEvent.
     *
     * @param hitter - the ball that were involved with the hit.
     */
    private void notifyHit(Ball hitter) {
        // Make a copy of the hitListeners before iterating over them.
        List<HitListener> listeners = new ArrayList<HitListener>(this.hitListeners);
        // Notify all listeners about a hit event:
        for (HitListener hl : listeners) {
            hl.hitEvent(this, hitter);
        }
    }
}
