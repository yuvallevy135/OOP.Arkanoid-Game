/*
 * Yuval Levy
 * 205781966
 */

package paddleandblock;

import geomrtyshapes.Ball;
import indicators.Counter;
import interfaces.HitListener;
import gamelevels.GameLevel;

/**
 * a paddleandblock.BlockRemover is in charge of removing blocks from the game, as well as keeping count of the number of
 * blocks that remain.
 *
 * @ author: Yuval Levy
 */
public class BlockRemover implements HitListener {
    //fileds.
    private GameLevel game;
    private Counter remainingBlocks;

    /**
     * Constructor.
     *
     * @param game            the game
     * @param remainingBlocks the remaining blocks
     */
    public BlockRemover(GameLevel game, Counter remainingBlocks) {
        this.game = game;
        this.remainingBlocks = remainingBlocks;
    }

    /**
     * This method removes the given paddleandblock.Block from the Game when the
     * paddleandblock.Block's life gets to 0 after a hit.
     *
     * @param beingHit the paddleandblock.Block that was involved in the hit
     * @param hitter   the geomrtyshapes.Ball that was involved in the hit
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        if (beingHit.getHitPoints() == 0) {
            beingHit.removeFromGame(this.game);
            beingHit.removeHitListener(this);
            this.remainingBlocks.decrease(1);
        }
        if (this.remainingBlocks.getValue() == 0) {
            this.game.getScore().increase(100);
        }
    }
}
