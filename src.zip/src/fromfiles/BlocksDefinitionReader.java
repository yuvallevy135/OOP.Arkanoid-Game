/*
 * Yuval Levy
 * 205781966
 */
package fromfiles;

import paddleandblock.Block;
import paddleandblock.BlocksFromSymbolsFactory;
import geomrtyshapes.Rectangle;
import geomrtyshapes.Point;
import interfaces.BlockCreator;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * getting java.io.Reader object to a file that is incharges of describing the block.
 * we read the lines from the block.txt to 3 arr lists. then re turn them to ArrayList <ArrayList<String>>
 * and return. we map them into 2 tree maps.
 */
public class BlocksDefinitionReader {
    /**
     * take from the file separately the sdef,bdef lines (from blocks_*.txt) into Array lists.
     *
     * @param reader the reader java.io.Reader Object to a file
     * @return ArrayList  the array list
     */
    public static ArrayList<ArrayList<String>> blocksLevelDescription(java.io.Reader reader) {
        BufferedReader is = null;
        String[] arraySplitter;
        // arrList that gets strings.
        ArrayList<String> defaultSeparatedSpaceList = new ArrayList<>();
        // has a line that starts with bdef.
        ArrayList<String> bdefLinesList = new ArrayList<>();
        // has a line that starts with sdef.
        ArrayList<String> sdefLinesList = new ArrayList<>();
        // all the 3 arrlists.
        ArrayList<ArrayList<String>> defaultBdefSdefList = new ArrayList<>();
        String line;
        // creating arr list of def lines.
        try {
            // we will warp that reads amd then the read chars.
            is = new BufferedReader(reader);
            line = is.readLine().trim();
            while (line != null) {
                // reaing arr list that will has in each of the member string:stsring.
                if (line.trim().startsWith("default")) {
                    arraySplitter = line.split(" ");
                    for (String string : arraySplitter) {
                        //remove the default from our list.
                        if (string.contains("default")) {
                            continue;
                        } else {
                            defaultSeparatedSpaceList.add(string.trim());
                        }
                    }
                } else if (line.trim().startsWith("bdef")) {
                    //create arr list that will have in each member string that starts with bdef.
                    bdefLinesList.add(line);
                } else if (line.trim().startsWith("sdef")) {
                    //create arr list that will have in each member string that starts with sdef.
                    sdefLinesList.add(line);
                }
                line = is.readLine().trim();
            }
        } catch (IOException e) {
            System.out.println("Something happened while reading ! 64");
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    System.out.println("Failed closing the file");
                }
            }
            // create all the 3 arr into one arr
            defaultBdefSdefList.add(defaultSeparatedSpaceList);
            defaultBdefSdefList.add(bdefLinesList);
            defaultBdefSdefList.add(sdefLinesList);
            return defaultBdefSdefList;
        }
    }

    /**
     * get a list that will have the members separated with space.
     * we will get a map of left string is the key and right string is values.
     *
     * @param deafaultSeparatedSpaceList the list.
     * @return Map
     */
    public static Map<String, String> mappingDefaultLine(ArrayList<String> deafaultSeparatedSpaceList) {
        Map<String, String> defaultLineMap = new TreeMap<>();
        String[] stringArray;
        if (deafaultSeparatedSpaceList.size() == 0) {
            // if the list is empty = return null.
            return null;
        } else {
            // run on each member and keys will be the left string and values will be the right.
            for (String str : deafaultSeparatedSpaceList) {
                if (str.contains(":")) {
                    stringArray = str.split(":");
                    String key = stringArray[0].trim();
                    String value = stringArray[1].trim();
                    defaultLineMap.put(key, value);
                }
            }
        }
        return defaultLineMap;
    }

    /**
     * get a list that has sdef or bdef lines.
     * we then create a map that key will be the symbol, the values.
     *
     * @param defLinesList a List<string></string>
     * @return Map<String ,   Map < String ,   String>>
     */
    public static Map<String, Map<String, String>> mappingDefLines(List<String> defLinesList) {
        // mapping the pairs except from the symbol.
        Map<String, String> mapPairsWithNoSymbol = new TreeMap<>();
        Map<String, Map<String, String>> mapWithSymbols = new TreeMap<String, Map<String, String>>();
        String[] splitWithSpaceArray;
        String symbolString = null;
        // split with spaces.
        for (String line : defLinesList) {
            // split with ":"
            splitWithSpaceArray = line.split(" ");
            for (int i = 1; i < splitWithSpaceArray.length; i++) {
                String[] splitWithColonArray = splitWithSpaceArray[i].split(":");
                if (splitWithColonArray[0].trim().equals("symbol")) {
                    symbolString = splitWithColonArray[1].trim();
                } else {
                    mapPairsWithNoSymbol.put(splitWithColonArray[0].trim(), splitWithColonArray[1].trim());

                }
            }
            // if no symbol = null.
            if (symbolString == null) {
                return null;
            }
            mapWithSymbols.put(symbolString, mapPairsWithNoSymbol);
            mapPairsWithNoSymbol = new TreeMap<>();
        }
        return mapWithSymbols;
    }

    /**
     * get map with bdef lines. return Map with block creator values.
     *
     * @param mappingBdefLines map
     * @return a map with block creators values.
     */
    public static Map<String, BlockCreator> creatorMap(Map<String, Map<String, String>> mappingBdefLines) {
        String theFirstKeys = null;
        Map<String, String> values = new TreeMap<>();
        Map<String, BlockCreator> blockCreatorMap = new TreeMap<>();
        String imageString;
        for (Map.Entry<String, Map<String, String>> m : mappingBdefLines.entrySet()) {
            Map<Integer, Color> integerColorMap = new TreeMap<>();
            Map<Integer, Image> integerImageMap = new TreeMap<>();
            theFirstKeys = m.getKey();
            values = m.getValue();
            int height = Integer.parseInt(values.get("height"));
            int width = Integer.parseInt(values.get("width"));
            int hitPoints = Integer.parseInt(values.get("hit_points"));
            String strokeString;
            if (values.containsKey("stroke")) {
                strokeString = values.get("stroke");
            } else {
                strokeString = null;
            }
            Color stroke = null;
            if (strokeString != null) {
                try {
                    stroke = ColorsParser.colorFromString(strokeString);
                } catch (Exception e) {
                    e.getMessage();
                }
            }
            final Color finalStroke = stroke;
            ColorsParser colorsParser = new ColorsParser();
            for (String keys : values.keySet()) {
                if (keys.trim().equals("fill")) {
                    if (values.get(keys).trim().startsWith("image")) {
                        imageString = values.get(keys).replace("image(", "").replace(")",
                                "");
                        try {
                            integerImageMap.put(1, ImageIO.read(ClassLoader.getSystemClassLoader()
                                    .getResourceAsStream(imageString)));
                        } catch (IOException e) {
                            System.out.println("Cant load this image");
                            System.exit(1);
                        }
                    } else {
                        try {
                            integerColorMap.put(1, colorsParser.colorFromString(values.get(keys)));
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                            System.exit(1);
                        }
                    }
                } else if (keys.startsWith("fill-")) {
                    int k = Integer.parseInt(keys.replace("fill-", "").trim());
                    if (values.get(keys).trim().startsWith("image")) {
                        imageString = values.get(keys).replace("image(", "").replace(")", "");
                        try {
                            integerImageMap.put(k, ImageIO.read(ClassLoader.getSystemClassLoader()
                                    .getResourceAsStream(imageString)));
                        } catch (IOException e) {
                            System.out.println("Cant load this image");
                        }
                    } else {
                        try {
                            integerColorMap.put(k, colorsParser.colorFromString(values.get(keys)));
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                            System.exit(1);
                        }
                    }
                }
            }
            // create the anonymos class.
            BlockCreator blockCreator = new BlockCreator() {
                @Override
                public Block create(int xPos, int yPos) {
                    Rectangle rectangle = new Rectangle(new Point(xPos, yPos), width, height);
                    Block gameBlock = new Block(rectangle, integerImageMap, integerColorMap, hitPoints);
                    gameBlock.addStorkeToBlock(finalStroke);
                    return gameBlock;
                }
            };
            blockCreatorMap.put(theFirstKeys, blockCreator);
        }
        return blockCreatorMap;
    }

    /**
     * get map with sdef lines. return Map with widths of the spacers..
     *
     * @param mappingSdefLines the mapping sdef lines
     * @return the map
     */
    public static Map<String, Integer> spacesMap(Map<String, Map<String, String>> mappingSdefLines) {
        Map<String, Integer> sdefStringInteger = new TreeMap<>();
        for (Map.Entry<String, Map<String, String>> entry : mappingSdefLines.entrySet()) {
            sdefStringInteger.put(entry.getKey(), Integer.parseInt(entry.getValue().get("width")));
        }
        return sdefStringInteger;
    }


    /**
     * getting 2 maps. one of bdefs map and a default map.
     * checking if the def map has a line witht a key which is a paddleandblock.
     *
     * @param defLinesMap     the bdef  map
     * @param defaultLinesMap the default lines map
     */
    public static void missingTheKeyTryDefault(Map<String, Map<String, String>> defLinesMap,
                                               Map<String, String> defaultLinesMap) {
        // the fields must contain paddleandblock.block.
        String[] defaultFields = {"width", "height", "hit_points", "stroke"};
        // run the map.
        if (defaultLinesMap != null) {
            for (Map.Entry<String, Map<String, String>> defMapEntry : defLinesMap.entrySet()) {
                // check if there is a field missing bdef and def lines.
                for (String defaultKeyString : defaultFields) {
                    if ((!(defMapEntry.getValue().containsKey("fill")) && !(defaultLinesMap.containsKey("fill")))
                            && (!(defMapEntry.getValue().containsKey("fill-1"))
                            && !(defaultLinesMap.containsKey("fill-1")))) {
                        System.out.println("The following fields: \"fill or fill-1\""
                                + "are missing in both: bdef and dafault lines");
                        System.exit(0);
                    } else if (!(defMapEntry.getValue().containsKey("fill"))
                            && !(defMapEntry.getValue().containsKey("fill-1"))) {
                        // if the fill missing in a bdef, but it is exists in the def line - add it to bdef line.
                        if (defaultLinesMap.containsKey("fill")) {
                            defMapEntry.getValue().put("fill", defaultLinesMap.get("fill"));
                        } else if (defaultLinesMap.containsKey("fill-1")) {
                            // if the fill missing in a bdef, but it is exists in the def line - add it to bdef line.
                            defMapEntry.getValue().put("fill-1", defaultLinesMap.get("fill-1"));
                        }
                    }
                    if (!(defMapEntry.getValue().containsKey(defaultKeyString))
                            && !(defaultLinesMap.containsKey(defaultKeyString)) && !defaultKeyString.equals("storke")) {
                        System.out.println("The following filed: \"" + defaultKeyString +
                                "\" is missing in both: bdef and default lines");
                    } else if (!(defMapEntry.getValue().containsKey(defaultKeyString))
                            && defaultLinesMap.containsKey(defaultKeyString)) {
                        defMapEntry.getValue().put(defaultKeyString, defaultLinesMap.get(defaultKeyString));
                    }
                }
            }
        }
    }

    /**
     * reading the bdef and sdef and def text lines.
     * crating block and spacers according to the lines.
     *
     * @param reader the reader
     * @return paddleandblock.BlocksFromSymbolsFactory
     */
    public static BlocksFromSymbolsFactory fromReader(java.io.Reader reader) {
        List<ArrayList<String>> blocksLevelDescription = blocksLevelDescription(reader);
        if (blocksLevelDescription == null) {
            System.out.println("No lines were found in the text");
            System.exit(0);
        }
        Map<String, String> defaultLineMap = mappingDefaultLine(blocksLevelDescription.get(0));
        Map<String, Map<String, String>> bdefMap = mappingDefLines(blocksLevelDescription.get(1));
        Map<String, Map<String, String>> sdefMap = mappingDefLines(blocksLevelDescription.get(2));
        missingTheKeyTryDefault(bdefMap, defaultLineMap);
        Map<String, BlockCreator> blockCreatorMap = creatorMap(bdefMap);
        Map<String, Integer> stringIntegerMap = spacesMap(sdefMap);
        BlocksFromSymbolsFactory blocksFromSymbolsFactory =
                new BlocksFromSymbolsFactory(stringIntegerMap, blockCreatorMap);
        return blocksFromSymbolsFactory;
    }
}
