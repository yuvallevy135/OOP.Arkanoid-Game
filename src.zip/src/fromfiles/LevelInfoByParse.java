/*
 * Yuval Levy
 * 205781966
 */
package fromfiles;

import paddleandblock.Block;
import geomrtyshapes.Velocity;
import interfaces.LevelInformation;
import interfaces.Sprite;

import java.util.List;

/**
 * describes a level like levelinfo from reading from a file.
 */
public class LevelInfoByParse implements LevelInformation {
    //fields.
    private List<Velocity> velocities;
    private int paddleSpeedVar;
    private int paddleWidthVar;
    private String levelNameString;
    private Sprite levelBackground;
    private List<Block> blocksPattern;
    private int removeBlock;

    /**
     * Constructor.
     *
     * @param velocities      the velocities
     * @param paddleSpeedVar  the paddle speed var
     * @param paddleWidthVar  the paddle width var
     * @param levelNameString the level name string
     * @param levelBackground the level background
     * @param blocksPattern   the blocks pattern
     * @param removeBlock     the remove block
     */
    public LevelInfoByParse(List<Velocity> velocities, int paddleSpeedVar, int paddleWidthVar,
                            String levelNameString, Sprite levelBackground, List<Block> blocksPattern, int removeBlock) {
        this.velocities = velocities;
        this.paddleSpeedVar = paddleSpeedVar;
        this.paddleWidthVar = paddleWidthVar;
        this.levelNameString = levelNameString;
        this.levelBackground = levelBackground;
        this.removeBlock = removeBlock;
        this.blocksPattern = blocksPattern;
    }

    /**
     * number of balls in this Level.
     *
     * @return number of balls in this level.
     */
    public int numberOfBalls() {
        return velocities.size();
    }

    /**
     * The initial velocity of each ball, Note that initialBallVelocities().size() == numberOfBalls().
     *
     * @return list that contains all the velocity.
     */
    public List<Velocity> initialBallVelocities() {
        return velocities;
    }

    /**
     * the paddles velocity.
     *
     * @return the paddle's velocity.
     */
    public int paddleSpeed() {
        return paddleSpeedVar;
    }

    /**
     * The Paddle's Width.
     *
     * @return the paddle's width.
     */
    public int paddleWidth() {
        return paddleWidthVar;
    }

    /**
     * the level name.
     *
     * @return string with the level's Name
     */

    public String levelName() {
        return levelNameString;
    }

    /**
     * Returns a sprite with the background of the level.
     *
     * @return sptite that describes the level background.
     */

    public Sprite getBackground() {
        return levelBackground;
    }

    /**
     * The Blocks of the level.
     * a block has its size, color and location.
     *
     * @return list of Blocks of the level.
     */

    public List<Block> blocks() {
        return blocksPattern;
    }

    /**
     * num of blocks to remove.
     *
     * @return int a num of blocks before we clear the level.
     */

    public int numberOfBlocksToRemove() {
        return removeBlock;
    }
}
