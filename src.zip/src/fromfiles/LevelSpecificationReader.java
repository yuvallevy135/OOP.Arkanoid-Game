/*
 * Yuval Levy
 * 205781966
 */
package fromfiles;

import backgrounds.LevelBackground;
import paddleandblock.Block;
import paddleandblock.BlocksFromSymbolsFactory;
import geomrtyshapes.Velocity;
import interfaces.LevelInformation;
import interfaces.Sprite;


import java.awt.Image;
import java.awt.Color;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * getting java.io.Reader object to a file that is incharges of describing the level.
 * reading the level desc and the blocks desc from the file into 2 arr list.
 * then we map them into 2 tree maps.
 */
public class LevelSpecificationReader {

    /**
     * getting java.io.Reader object to a file that is incharges of describing the level.
     * getting the block from the file into an arr list from the START block to the END blocks.
     *
     * @param reader the reader
     * @return the array list
     */
    public static ArrayList<String> theBlocksDescription(BufferedReader reader) {
        String theBeginLineLevel;
        ArrayList<String> linesOfLevel = null;
        // try to wrap.
        try {
            // wrapper that is reading. then the wrapper that read chars.
            linesOfLevel = new ArrayList<String>();
            // skipping all the lins before the START_LEVEK
            while (true) {
                theBeginLineLevel = reader.readLine().trim();
                if (theBeginLineLevel.equals("START_LEVEL") || theBeginLineLevel == null) {
                    break;
                }
            }
            String theEndLineLevel;
            //if we still reading the line - keep reading the next.
            if (theBeginLineLevel.equals("START_LEVEL")) {
                theEndLineLevel = reader.readLine().trim();
            } else {
                theEndLineLevel = theBeginLineLevel;
            }
            // get the lines into an arr list - until u read END_BLOCKS
            while (true) {
                if (theEndLineLevel == null) {
                    return null;
                } else if (theEndLineLevel.equals("END_LEVEL")) {
                    break;
                } else {
                    if (!theEndLineLevel.isEmpty()) {
                        linesOfLevel.add(theEndLineLevel);
                    }
                }
                theEndLineLevel = reader.readLine().trim();
            }
        } catch (IOException e) {
            System.out.println("Something happened while trying to read.");
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    System.out.println("It Failed closing the file.");
                }
            }
        }
        return linesOfLevel;
    }

    /**
     * the method gets a filename reader and returns LevelInformations.
     *
     * @param reader the reader
     * @return the list
     */
    public List<LevelInformation> fromReader(java.io.Reader reader) {
        List<LevelInformation> levelInfo = new ArrayList<>();
        List<List<String>> theTextLevelLines = new ArrayList<>();
        BufferedReader bufferedReader = new BufferedReader(reader);
        try {
            theTextLevelLines = describeLevel(bufferedReader);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.exit(0);
        }
        try {
            for (int i = 0; i < theTextLevelLines.size(); i++) {
                LevelInformation afterParse = createLevelInfo(theTextLevelLines.get(i));
                levelInfo.add(afterParse);
            }
        } catch (NullPointerException e) {
            System.out.println("The level text file is probably empty.");
        }
        return levelInfo;
    }

    /**
     * getting the java.io.Reader which is incharges of describing the level.
     * geeting the block into an arr list.
     *
     * @param reader the reader
     * @return the list
     */
    public static List<List<String>> describeLevel(BufferedReader reader) {
        String theBeginLineLevel;
        List<List<String>> linesOfLevel = new ArrayList<>();
        try {
            theBeginLineLevel = reader.readLine().trim();
        } catch (IOException e) {
            System.out.println("Cant read level definition file");
            return null;
        }
        while (theBeginLineLevel != null) {
            List<String> infoLevel = new ArrayList<>();
            // try to wrap.
            try {
                // skip all the lines before START_LEVEL.
                while (true) {
                    theBeginLineLevel = reader.readLine().trim();
                    if (theBeginLineLevel.contains("START_LEVEL") || theBeginLineLevel == null) {
                        break;
                    }
                }
                String theEndLineLevel;
                if (theBeginLineLevel.equals("START_LEVEL")) {
                    theEndLineLevel = reader.readLine().trim();
                } else {
                    theEndLineLevel = theBeginLineLevel;
                }
                // get all the lines into an arr. do that until u reach END_BLOCKS
                while (true) {
                    // if it reaches the end before "END_BLOCKS = return null.
                    if (theEndLineLevel == null) {
                        return null;
                    } else if (theEndLineLevel.equals("END_LEVEL")) {
                        break;
                    } else {
                        if (!theEndLineLevel.isEmpty()) {
                            infoLevel.add(theEndLineLevel);
                        }
                    }
                    theEndLineLevel = reader.readLine().trim();
                }
                linesOfLevel.add(infoLevel);
                theBeginLineLevel = theEndLineLevel;
            } catch (IOException e) {
                System.out.println("Something happened while trying to read.");
            } catch (NullPointerException e) {
                return linesOfLevel;

            }
        }
        return linesOfLevel;
    }

    /**
     * getting a list  and return a map. keys are the strings from the left and values are from the right.
     *
     * @param linesOfLevel the lines of level
     * @return the map
     */
    public static Map<String, String> mappingLinesInLevel(List<String> linesOfLevel) {
        String[] arrayString;
        Map<String, String> mapOfLevelLines = new TreeMap<>();
        for (String line : linesOfLevel) {
            if (line.contains(":")) {
                arrayString = line.split(":");
                String key = arrayString[0].trim();
                String value = arrayString[1].trim();
                mapOfLevelLines.put(key, value);
            }
        }
        return mapOfLevelLines;
    }


    /**
     * Parser level name string.
     *
     * @param mapOfLevelLines the map of level lines
     * @return the string
     */
    public String parserLevelName(Map<String, String> mapOfLevelLines) {
        String levelName = "level_name";
        return mapOfLevelLines.get(levelName).trim();
    }


    /**
     * Parser of balls velocity list.
     *
     * @param mapOfLevelLines the map of level lines
     * @return the list
     */
    public List<Velocity> parserOfBallsVelocity(Map<String, String> mapOfLevelLines) {
        List<Velocity> velocities = new ArrayList<>();
        String theBallVelocity = "ball_velocities";
        String valueOfBallVelocity = mapOfLevelLines.get(theBallVelocity).trim();
        for (String velocity : valueOfBallVelocity.split(" ")) {
            String[] dxDy = velocity.split(",");
            Velocity velo = new Velocity(Double.parseDouble(dxDy[0]), Double.parseDouble(dxDy[1]));
            velocities.add(Velocity.fromAngleAndSpeed(velo.getDx(), velo.getDy()));
        }
        return velocities;
    }

    /**
     * Parser of back ground sprite.
     *
     * @param mapOfLevelLines the map of level lines
     * @return the sprite
     */
    public Sprite parserOfBackGround(Map<String, String> mapOfLevelLines) {
        Image image;
        Sprite backGround;
        String stringImage;
        String valueOfBackGround = mapOfLevelLines.get("background").trim();
        Color color = null;
        LevelBackground levelBackground = null;
        if (valueOfBackGround.contains("image")) {
            stringImage = valueOfBackGround.trim().replace("image(", "")
                    .replace(")", "");
            try {
                image = ImageIO.read(ClassLoader.getSystemClassLoader().getResourceAsStream(stringImage));
                levelBackground = new LevelBackground(null, image);
            } catch (IOException e) {
                System.out.println("Something happened while getting the image of backgrond.");
                System.exit(1);
            }
        } else {
            ColorsParser colorsParser = new ColorsParser();
            try {
                color = colorsParser.colorFromString(valueOfBackGround.trim());
            } catch (Exception e) {
                System.out.println("Something happened while trying to parse the color.");
                e.getMessage();
            }
            levelBackground = new LevelBackground(color, null);
        }
        backGround = levelBackground;
        return backGround;
    }

    /**
     * Parser of paddle speed int.
     *
     * @param mapOfLevelLines the map of level lines
     * @return the int
     */
    public int parserOfPaddleSpeed(Map<String, String> mapOfLevelLines) {
        String speedPaddle = mapOfLevelLines.get("paddle_speed").trim();
        return Integer.parseInt(speedPaddle);
    }

    /**
     * Parser of paddle width int.
     *
     * @param mapOfLevelLines the map of level lines
     * @return the int
     */
    public int parserOfPaddleWidth(Map<String, String> mapOfLevelLines) {
        String widthPaddle = mapOfLevelLines.get("paddle_width").trim();
        return Integer.parseInt(widthPaddle);
    }

    /**
     * Parser of block x start int.
     *
     * @param mapOfLevelLines the map of level lines
     * @return the int
     */
    public int parserOfBlockXStart(Map<String, String> mapOfLevelLines) {
        String x = mapOfLevelLines.get("blocks_start_x").trim();
        return Integer.parseInt(x);
    }

    /**
     * Parser of block y start int.
     *
     * @param mapOfLevelLines the map of level lines
     * @return the int
     */
    public int parserOfBlockYStart(Map<String, String> mapOfLevelLines) {
        String y = mapOfLevelLines.get("y").trim();
        return Integer.parseInt(y);
    }

    /**
     * Parser of the row height int.
     *
     * @param mapOfLevelLines the map of level lines
     * @return the int
     */
    public int parserOfTheRowHeight(Map<String, String> mapOfLevelLines) {
        String height = mapOfLevelLines.get("row_height").trim();
        return Integer.parseInt(height);
    }

    /**
     * Parser of num blocks int.
     *
     * @param mapOfLevelLines the map of level lines
     * @return the int
     */
    public int parserOfNumBlocks(Map<String, String> mapOfLevelLines) {
        String num = mapOfLevelLines.get("num_blocks").trim();
        return Integer.parseInt(num);
    }

    /**
     * Parser of blocks list list.
     *
     * @param theBlockLinesDef the the block lines def
     * @param charsOfBlocks    the chars of blocks
     * @return the list
     */
    public List<Block> parserOfBlocksList(Map<String, String> theBlockLinesDef, List<String> charsOfBlocks) {
        int xPos = Integer.parseInt(theBlockLinesDef.get("blocks_start_x"));
        int yPos = Integer.parseInt(theBlockLinesDef.get("blocks_start_y"));
        List<Block> theBlockList = new ArrayList<Block>();
        int indicatorOfYPos = yPos;
        int indicatorOfXPos;
        int heightsOfRows = Integer.parseInt(theBlockLinesDef.get("row_height"));
        String theBlockFile = theBlockLinesDef.get("block_definitions");
        BlocksFromSymbolsFactory blocksFromSymbolsFactory = null;
        try {
            InputStreamReader inputStreamReader = new InputStreamReader(ClassLoader.getSystemClassLoader().
                    getResourceAsStream(theBlockFile));
            blocksFromSymbolsFactory = BlocksDefinitionReader.fromReader(inputStreamReader);
        } catch (Exception e) {
            System.out.println("Something haapened while trying to load the file.");
        }
        int startOfLine = 0;
        int endOfLine = 0;
        for (int i = 0; i < charsOfBlocks.size(); i++) {
            if (!(charsOfBlocks.get(i).contains("START_BLOCKS"))) {
                startOfLine++;
                continue;
            }
            startOfLine++;
            break;
        }
        for (int i = startOfLine; i < charsOfBlocks.size(); i++) {
            if (!(charsOfBlocks.get(i).contains("END_BLOCKS"))) {
                endOfLine++;
                continue;
            }
            break;
        }
        endOfLine = endOfLine + startOfLine;
        for (int i = startOfLine; i < endOfLine; i++) {
            indicatorOfXPos = xPos;
            String rowOfBlocks = charsOfBlocks.get(i);
            for (int j = 0; j < rowOfBlocks.length(); j++) {
                String theSymbol = Character.toString(rowOfBlocks.charAt(j));
                if (blocksFromSymbolsFactory.isSpaceSymbol(theSymbol)) {
                    indicatorOfXPos += blocksFromSymbolsFactory.getSpaceWidth(theSymbol);
                    continue;
                }
                if (blocksFromSymbolsFactory.isBlockSymbol(theSymbol)) {
                    Block block = blocksFromSymbolsFactory.getBlock(theSymbol, indicatorOfXPos, indicatorOfYPos);
                    theBlockList.add(block);
                    indicatorOfXPos += block.getWidth();
                    continue;
                } else {
                    System.out.println("Error - incorrect space block symbol / incorrect block");
                    continue;
                }
            }
            indicatorOfYPos += heightsOfRows;
            indicatorOfXPos = xPos;
        }
        return theBlockList;
    }

    /**
     * get a list that has the levels lines.
     * return  levelinfo of the level
     *
     * @param linesOfLevel list that has all the level limes.
     * @return the level information of the level.
     */
    public LevelInformation createLevelInfo(List<String> linesOfLevel) {
        Map<String, String> mapOfLevelLines = mappingLinesInLevel(linesOfLevel);
        String levelName = parserLevelName(mapOfLevelLines);
        int paddleWidth = parserOfPaddleWidth(mapOfLevelLines);
        int paddleSpeed = parserOfPaddleSpeed(mapOfLevelLines);
        int removeBlock = parserOfNumBlocks(mapOfLevelLines);
        Sprite backGround = parserOfBackGround(mapOfLevelLines);
        List<Velocity> velocitiesOfBalls = parserOfBallsVelocity(mapOfLevelLines);
        List<Block> blocks = parserOfBlocksList(mapOfLevelLines, linesOfLevel);
        return new LevelInfoByParse(velocitiesOfBalls, paddleSpeed, paddleWidth, levelName,
                backGround, blocks, removeBlock);
    }

}

