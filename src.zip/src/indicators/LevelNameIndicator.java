/*
 * Yuval Levy
 * 205781966
 */

package indicators;

import gamelevels.GameLevel;
import biuoop.DrawSurface;
import interfaces.LevelInformation;
import interfaces.Sprite;

import java.awt.Color;

/**
 * The type Level name indicator.
 */
public class LevelNameIndicator implements Sprite {
    /**
     * The constant HEIGHT_TEXT.
     */
// where to write the num of lives of the screen.
    public static final int HEIGHT_TEXT = 20;
    /**
     * The constant WIDTH_TEXT.
     */
    public static final int WIDTH_TEXT = 470;
    private LevelInformation levelnfo;

    /**
     * Constructor.
     *
     * @param levelnfo the num of lives that the player has at the moment.
     */
    public LevelNameIndicator(LevelInformation levelnfo) {
        this.levelnfo = levelnfo;
    }

    /**
     * this func draws it on the screen.
     *
     * @param d - the DrawSurface of the GUI that was created.
     */
    public void drawOn(DrawSurface d) {
        d.setColor(Color.RED);
        d.drawText(WIDTH_TEXT, HEIGHT_TEXT, "Level Name:" + levelnfo.levelName(), 20);
    }

    /**
     * notify the sprite that time has passed.
     */
    public void timePassed() {
    }

    /**
     * this func adds indicators.LivesIndicator to the game.
     *
     * @param game the game that we want to add the indicators.LivesIndicator to.
     */
    public void addToGame(GameLevel game) {
        game.addSprite(this);
    }
}
