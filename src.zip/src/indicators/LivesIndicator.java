/*
 * Yuval Levy
 * 205781966
 */

package indicators;

import biuoop.DrawSurface;
import interfaces.Sprite;
import gamelevels.GameLevel;

import java.awt.Color;

/**
 * Indicates the player's num of lives.
 *
 * @ author: Yuval Levy
 */
public class LivesIndicator implements Sprite {
    // where to write the num of lives of the screen.
    public static final int HEIGHT_TEXT = 20;
    public static final int WIDTH_TEXT = 70;
    private Counter numOfLives;

    /**
     * Constructor.
     *
     * @param numOfLives the num of lives that the player has at the moment.
     */
    public LivesIndicator(Counter numOfLives) {
        this.numOfLives = numOfLives;
    }

    /**
     * this func draws it on the screen.
     *
     * @param d - the DrawSurface of the GUI that was created.
     */
    public void drawOn(DrawSurface d) {
        d.setColor(Color.RED);
        d.drawText(WIDTH_TEXT, HEIGHT_TEXT, "Lives: " + Integer.toString(this.numOfLives.getValue()), 20);
    }

    /**
     * notify the sprite that time has passed.
     */
    public void timePassed() {
    }

    /**
     * this func adds indicators.LivesIndicator to the game.
     *
     * @param game the game that we want to add the indicators.LivesIndicator to.
     */
    public void addToGame(GameLevel game) {
        game.addSprite(this);
    }
}
