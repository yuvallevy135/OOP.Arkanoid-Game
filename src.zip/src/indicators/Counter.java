/*
 * Yuval Levy
 * 205781966
 */

package indicators;

/**
 * A package that just counts stuff.
 *
 * @ author: Yuval Levy
 */
public class Counter {

    //fields.
    private int counter;

    /**
     * Constructor.
     *
     * @param counter the counter
     */
    public Counter(int counter) {
        this.counter = counter;
    }

    /**
     * add number to current count.
     *
     * @param number the number that we want to add.
     */
    public void increase(int number) {
        this.counter += number;
    }

    /**
     * subtract number from current count.
     *
     * @param number the number that we want to subtract.
     */
    public void decrease(int number) {
        this.counter -= number;
    }

    /**
     * get current count.
     *
     * @return the int
     */
    public int getValue() {
        return this.counter;
    }
}