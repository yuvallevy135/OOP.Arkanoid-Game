/*
 * Yuval Levy
 * 205781966
 */

package indicators;

import paddleandblock.Block;
import geomrtyshapes.Ball;
import indicators.Counter;
import interfaces.HitListener;

/**
 * Tracking the Score. hiiting a block  5 point, destroying a block 10 point, destroying all the block 100 points.
 */
public class ScoreTrackingListener implements HitListener {
    private Counter currentScore;

    /**
     * Constructor.
     *
     * @param scoreCounter the score counter
     */
    public ScoreTrackingListener(Counter scoreCounter) {
        this.currentScore = scoreCounter;
    }

    /**
     * uptading the score.
     *
     * @param beingHit the paddleandblock.Block that was involved in the hit
     * @param hitter   the geomrtyshapes.Ball that was involved in the hit
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        currentScore.increase(5);
        if (beingHit.getHitPoints() == 0) {
            currentScore.increase(10);
        }
    }
}