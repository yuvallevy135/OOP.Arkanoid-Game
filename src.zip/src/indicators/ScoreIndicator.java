/*
 * Yuval Levy
 * 205781966
 */

package indicators;

import biuoop.DrawSurface;
import interfaces.Sprite;
import gamelevels.GameLevel;

import java.awt.Color;

/**
 * Indicates the player's score.
 *
 * @ author: Yuval Levy
 */
public class ScoreIndicator implements Sprite {
    // where to print and the background.
    public static final int START_COR = 0;
    public static final int HEIGHT = 25;
    public static final int WIDTH = 800;
    public static final int HEIGHT_TEXT = 20;
    public static final int WIDTH_TEXT = 350;
    private Counter score;

    /**
     * Constructor.
     *
     * @param score the score that the player has at the moment.
     */
    public ScoreIndicator(Counter score) {
        this.score = score;
    }

    /**
     * this func draws it on the screen.
     *
     * @param d - the DrawSurface of the GUI that was created.
     */
    public void drawOn(DrawSurface d) {
        d.setColor(Color.RED);
        d.drawText(WIDTH_TEXT, HEIGHT_TEXT, "Score: " + Integer.toString(this.score.getValue()), 20);
    }

    /**
     * notify the sprite that time has passed.
     */
    public void timePassed() {

    }

    /**
     * this func adds indicators.ScoreIndicator to the game.
     *
     * @param game the game that we want to add the indicators.ScoreIndicator to.
     */
    public void addToGame(GameLevel game) {
        game.addSprite(this);
    }
}
