/*
 * Yuval Levy
 * 205781966
 */
package animation;

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import interfaces.Animation;


/**
 * extracts the "waiting-for-key-press" behavior away from the different Animations
 * into a KeyPressStoppableAnimation decorator-class that will wrap an existing animation and
 * add a "waiting-for-key" behavior to it.
 *
 * @ author: Yuval Levy
 */
public class KeyPressStoppableAnimation implements Animation {
    //fields.
    private KeyboardSensor sensor;
    private String key;
    private Animation animation;
    private boolean isAlreadyPressed;
    private boolean stopIt;

    /**
     * Constructor..
     *
     * @param sensor    KeyboardSensor
     * @param key       the key that stops the Animation
     * @param animation the animation we want to stop.
     */
    public KeyPressStoppableAnimation(KeyboardSensor sensor, String key, Animation animation) {
        this.sensor = sensor;
        this.key = key;
        this.animation = animation;
        this.isAlreadyPressed = true;
        this.stopIt = false;
    }

    /**
     * in charge of the logic of this animation.
     *
     * @param d this drawsurface.
     */
    public void doOneFrame(DrawSurface d) {
        this.animation.doOneFrame(d);
        // if stop key pressed one - stop the animation.
        if (this.sensor.isPressed(key) && !(isAlreadyPressed)) {
            this.stopIt = true;
        } else if (!(this.sensor.isPressed(key))) {
            isAlreadyPressed = false;
        }
    }

    /**
     * determines when to stop the interfaces.Animation. if true the animation will stop,
     *
     * @return Boolean needToStop.
     */
    public boolean shouldStop() {
        return this.stopIt;
    }
}
