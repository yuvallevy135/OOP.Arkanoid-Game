/*
 * Yuval Levy
 * 205781966
 */
package animation;

import biuoop.DrawSurface;
import biuoop.GUI;
import interfaces.Animation;

/**
 * AnimationRunner takes an Animation object and runs it.
 *
 * @ author: Yuval Levy
 */
public class AnimationRunner {
    // fields
    private GUI gui;
    private int framesPerSecond;

    /**
     * Instantiates a new Animation runner.
     *
     * @param gui             the gui of the game.
     * @param framesPerSecond the frames per second
     */
    public AnimationRunner(GUI gui, int framesPerSecond) {
        this.gui = gui;
        // gets 60.
        this.framesPerSecond = framesPerSecond;
    }

    /**
     * runs the given interfaces.Animation's Frames until shouldStop == true.
     *
     * @param animation the animation we run.
     */
    public void run(Animation animation) {
        biuoop.Sleeper sleeper = new biuoop.Sleeper();
        int millisecondsPerFrame = 1000 / this.framesPerSecond;
        //one frame each iteration. shouldStop() is in charge to stop.
        while (!animation.shouldStop()) {
            long startTime = System.currentTimeMillis(); // timing
            DrawSurface d = gui.getDrawSurface();

            animation.doOneFrame(d);

            gui.show(d);
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
    }

    /**
     * Gets gui.
     *
     * @return the gui
     */
    public GUI getGui() {
        return this.gui;
    }
}
