/*
 * Yuval Levy
 * 205781966
 */
package animation;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import interfaces.Menu;
import interfaces.Animation;


/**
 * Describe the menu. The game will start and the user will have a menu with options to chose.
 * For now it has:
 * Press "s" to start a new game.
 * Press "h" to see the high scores.
 * Press "q" to quit.
 *
 * @param <T> it desribes the return types.
 */
public class MenuAnimation<T> implements Menu<T>, Animation {
    private List<Menu<T>> subMenuList;
    private AnimationRunner ar;
    private T status;
    private List<Boolean> booleanSubMenu;
    private List<String> listKeys;
    private String titleOfMenu;
    private List<String> listMessages;
    private List<T> selections;
    private KeyboardSensor keyboard;
    private boolean stopIt;

    /**
     * constructor..
     *
     * @param ar          the animation runner
     * @param titleOfMenu KeyboardSensor
     * @param keyboard    string
     */
    public MenuAnimation(AnimationRunner ar, String titleOfMenu, KeyboardSensor keyboard) {
        this.ar = ar;
        this.subMenuList = new ArrayList<>();
        this.booleanSubMenu = new ArrayList<>();
        this.titleOfMenu = titleOfMenu;
        this.keyboard = keyboard;
        this.status = null;
        this.listKeys = new ArrayList<>();
        this.listMessages = new ArrayList<>();
        this.selections = new ArrayList<>();
        this.stopIt = false;
    }

    /**
     * another menu to the main menu.
     *
     * @param key     - a key is pressed and a submenu will be running after.
     * @param message - String - the next sub menu
     * @param subMenu - creating and showing the sub menu
     */
    public void addSubMenu(String key, String message, Menu<T> subMenu) {
        this.listKeys.add(key);
        this.listMessages.add(message);
        this.selections.add(null);
        this.subMenuList.add(subMenu);
        this.booleanSubMenu.add(true);
    }

    /**
     * it adds a selection to the menu.
     *
     * @param key       - String - the key is pressed in the menu and the specific animation will run.
     * @param message   - String - explains what is the next animation.
     * @param returnVal T - creating and showing the specific animation
     */

    public void addSelection(String key, String message, T returnVal) {
        listKeys.add(key);
        listMessages.add(message);
        selections.add(returnVal);
        subMenuList.add(null);
        booleanSubMenu.add(false);
    }

    /**
     * return the status of this menu.
     *
     * @return T status.
     */
    public T getStatus() {
        T statusNow = this.status;
        this.stopIt = false;
        this.status = null;
        return statusNow;
    }

    /**
     * the frame of the animation
     *
     * @param d this drawsurface.
     */
    public void doOneFrame(DrawSurface d) {
        int widthKey = d.getWidth() / 4;
        int heightKey = d.getHeight() / 3;
        d.setColor(new Color(0xBCBC95));
        d.fillRectangle(0, 0, 800, 600);
        d.setColor(new Color(0xE6DA27));
        d.drawText(d.getWidth() / 10, d.getHeight() / 10, this.titleOfMenu, 50);
        d.setColor(Color.BLACK);
        for (int i = 0; i < listKeys.size(); i++) {
            d.drawText(widthKey, heightKey, "(" + listKeys.get(i) + ") - " + listMessages.get(i), 35);
            heightKey += 50;
        }
        // if one of the keys is pressed - go to the animtion.
        for (int i = 0; i < listKeys.size(); i++) {
            if (keyboard.isPressed(listKeys.get(i)) && (this.booleanSubMenu.get(i))) {
                this.ar.run(this.subMenuList.get(i));
                // stop the animation.
                this.stopIt = true;
                // set the status with the animation we need to show.
                this.status = this.subMenuList.get(i).getStatus();
                break;
            } else if (keyboard.isPressed(listKeys.get(i)) && !(this.booleanSubMenu.get(i))) {
                this.stopIt = true;
                this.status = this.selections.get(i);
            }
        }
    }

    /**
     * determines when to stop the interfaces.Animation. if true the animation will stop,
     *
     * @return Boolean needToStop.
     */
    public boolean shouldStop() {
        return this.stopIt;
    }

    /**
     * makes sure when another animatio is called, that we animation is not over.
     */
    public void stopAnimation() {
        this.status = null;
        this.stopIt = false;
    }
}
