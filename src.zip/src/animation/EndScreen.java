/*
 * Yuval Levy
 * 205781966
 */
package animation;

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import interfaces.Animation;

import java.awt.Color;

/**
 * if the player lost all his lives - the following sentence will be: "Game Over. Your score is X".
 * if the player won the following sentence will be: "You Win! Your score is X"
 * X is the score of the player.
 *
 * @ author: Yuval Levy
 */
public class EndScreen implements Animation {
    private boolean gameOver;
    private KeyboardSensor keyboardSensor;
    private boolean stopIt;
    private int score;

    /**
     * Constructor..
     *
     * @param gameOver       if true then game over, else win.
     * @param keyboardSensor the keyboard sensor
     * @param score          the current score
     */
    public EndScreen(boolean gameOver, KeyboardSensor keyboardSensor, int score) {
        this.gameOver = gameOver;
        this.keyboardSensor = keyboardSensor;
        this.score = score;
        // when to stop animation.
        this.stopIt = false;
    }

    /**
     * in charge of the logic of this animation.
     *
     * @param d this drawsurface.
     */
    public void doOneFrame(DrawSurface d) {
        // background.
        d.setColor(Color.BLACK);
        d.fillRectangle(0, 0, 800, 800);
        d.setColor(Color.WHITE);
        // if the player lost then game over and print the following sentence
        if (gameOver) {
            d.drawText((d.getWidth() / 4) - 10, d.getHeight() / 2,
                    "Game Over. Your score is: " + this.score, 32);
        } else {
            // the player won and print the following sentence.
            d.drawText((d.getWidth() / 5) + 25, d.getHeight() / 2,
                    "You Win! Your score is: " + this.score, 32);
        }
        d.drawText((d.getWidth() / 5) + 60, 400, "Press 'SPACE' to proceed", 32);
    }

    /**
     * determines when to stop the interfaces.Animation. if true the animation will stop,
     *
     * @return Boolean needToStop.
     */
    public boolean shouldStop() {
        return this.stopIt;
    }
}
