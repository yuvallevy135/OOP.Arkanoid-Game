/*
 * Yuval Levy
 * 205781966
 */

package animation;

import biuoop.DrawSurface;
import interfaces.Animation;
import biuoop.KeyboardSensor;


/**
 * Pauses the game when "p" is pressed.
 *
 * @ author: Yuval Levy
 */
public class PauseScreen implements Animation {
    //fields.
    private KeyboardSensor keyboard;
    private boolean stop;

    /**
     * Constructor.
     *
     * @param k the KeyboardSensor
     */
    public PauseScreen(KeyboardSensor k) {
        this.keyboard = k;
        // tells us if to stop or not.
        this.stop = false;
    }

    /**
     * in charge of the logic of this animation.
     *
     * @param d this drawsurface.
     */
    public void doOneFrame(DrawSurface d) {
        d.drawText(d.getWidth() / 5, d.getHeight() / 2, "Paused -- press SPACE to continue", 32);
    }

    /**
     * determines when to stop the interfaces.Animation. if true the animation will stop,
     *
     * @return Boolean needToStop.
     */
    public boolean shouldStop() {
        return this.stop;
    }
}
