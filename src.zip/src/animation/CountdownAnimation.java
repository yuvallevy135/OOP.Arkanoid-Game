/*
 * Yuval Levy
 * 205781966
 */

package animation;


import biuoop.DrawSurface;
import gamelevels.SpriteCollection;
import interfaces.Animation;
import interfaces.LevelInformation;

import java.awt.Color;


/**
 * at the beginning of a level and after a player loses all ball, we will have a counting
 * from 3 - 1 and GO and then the turn will be again.
 *
 * @ author: Yuval Levy
 */
public class CountdownAnimation implements Animation {
    //fields.
    private double numOfSeconds;
    private int countFrom;
    private SpriteCollection gameScreen;
    private boolean needStop;
    private int counter;
    private LevelInformation levelInfo;

    /**
     * Constructor..
     *
     * @param numOfSeconds the num of seconds of the animation before the turn is on again.
     * @param countFrom    the count from we start to count
     * @param gameScreen   all the sprites of the game that call this animation.
     * @param levelInfo    info about the level.
     */
    public CountdownAnimation(double numOfSeconds, int countFrom, SpriteCollection gameScreen,
                              LevelInformation levelInfo) {
        this.numOfSeconds = numOfSeconds;
        this.countFrom = countFrom;
        this.gameScreen = gameScreen;
        // if its true we will stop the animation.
        this.needStop = false;
        // counts the times we call doOneFrame.
        this.counter = 0;
        this.levelInfo = levelInfo;
    }

    /**
     * in charge of the logic of this animation.
     *
     * @param d this drawsurface.
     */
    public void doOneFrame(DrawSurface d) {
        biuoop.Sleeper sleeper = new biuoop.Sleeper();
        // draw the background.
        levelInfo.getBackground().drawOn(d);
        gameScreen.drawAllOn(d);
        int milSecWait = (1000 * (int) numOfSeconds) / (1 + countFrom);
        d.setColor(Color.GRAY);
        // set white color because the first level is black.
        if (levelInfo.levelName().equals("Direct Hit")) {
            d.setColor(Color.WHITE);
        }
        // show a number or GO.
        if (counter == 0) {
            d.drawText(d.getWidth() / 2, d.getHeight() / 2, "3", 100);
        } else if (counter == 1) {
            d.drawText(d.getWidth() / 2, d.getHeight() / 2, "2", 100);
            sleeper.sleepFor(milSecWait);
        } else if (counter == 2) {
            d.drawText(d.getWidth() / 2, d.getHeight() / 2, "1", 100);
            sleeper.sleepFor(milSecWait);
        } else if (counter == 3) {
            d.drawText((d.getWidth() / 2) - 60, d.getHeight() / 2, "GO! ", 100);
            sleeper.sleepFor(milSecWait);
        } else {
            needStop = true;
            sleeper.sleepFor(milSecWait);
        }
        counter++;
    }

    /**
     * determines when to stop the interfaces.Animation. if true the animation will stop,
     *
     * @return Boolean needToStop.
     */
    public boolean shouldStop() {
        return needStop;
    }
}
