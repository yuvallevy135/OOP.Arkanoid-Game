/*
 * Yuval Levy
 * 205781966
 */
package backgrounds;

import biuoop.DrawSurface;
import interfaces.Sprite;

import java.awt.Color;

/**
 * background of level1.
 *
 * @ author: Yuval Levy
 */
public class BackGround1 implements Sprite {
    /**
     * draw the sprite on the screen.
     *
     * @param d - the DrawSurface.
     */
    public void drawOn(DrawSurface d) {
        d.setColor(Color.BLACK);
        d.fillRectangle(0, 20, 800, 600);
        d.setColor(Color.BLUE);
        d.drawCircle(400, 200, 120);
        d.drawCircle(400, 200, 90);
        d.drawCircle(400, 200, 60);
        d.drawLine(400, 20, 400, 170);
        d.drawLine(400, 230, 400, 360);
        d.drawLine(210, 200, 360, 200);
        d.drawLine(440, 200, 590, 200);
    }

    /**
     * notify the sprite that time has passed.
     */
    public void timePassed() {

    }
}
