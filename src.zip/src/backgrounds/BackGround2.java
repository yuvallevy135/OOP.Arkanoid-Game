/*
 * Yuval Levy
 * 205781966
 */
package backgrounds;

import biuoop.DrawSurface;
import interfaces.Sprite;

import java.awt.Color;

/**
 * background of level2.
 *
 * @ author: Yuval Levy
 */
public class BackGround2 implements Sprite {
    /**
     * draw the sprite on the screen.
     *
     * @param d - the DrawSurface.
     */
    public void drawOn(DrawSurface d) {

        d.setColor(Color.WHITE);
        d.fillRectangle(0, 20, 800, 600);
        d.setColor(new Color(241, 237, 198));
        for (int i = 0; i < 150; i++) {
            d.drawLine(150, 120, 5 * i, 230);
        }
        d.fillCircle(150, 120, 60);
        d.setColor(new Color(241, 238, 137));
        d.fillCircle(150, 120, 50);
        d.setColor(new Color(255, 251, 1));
        d.fillCircle(150, 120, 40);
    }

    /**
     * notify the sprite that time has passed.
     */
    public void timePassed() {

    }
}
