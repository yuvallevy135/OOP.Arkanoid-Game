/*
 * Yuval Levy
 * 205781966
 */
package backgrounds;

import biuoop.DrawSurface;
import interfaces.Sprite;

import java.awt.Color;

/**
 * background of level4.
 *
 * @ author: Yuval Levy
 */
public class BackGround4 implements Sprite {
    /**
     * draw the sprite on the screen.
     *
     * @param d - the DrawSurface.
     */
    public void drawOn(DrawSurface d) {
        d.setColor(new Color(91, 126, 211));
        d.fillRectangle(0, 20, 800, 600);

        d.setColor(Color.WHITE);
        for (int i = 0; i < 10; i++) {
            d.drawLine(145 + (5 * i), 350, 120 + (10 * i), 600);
        }
        d.setColor(new Color(188, 186, 164));
        d.fillCircle(140, 340, 20);
        d.fillCircle(165, 360, 30);
        d.setColor(new Color(172, 170, 142));
        d.fillCircle(180, 350, 30);
        d.fillCircle(200, 365, 30);
        d.fillCircle(220, 380, 25);


        d.setColor(Color.WHITE);
        for (int i = 0; i < 10; i++) {
            d.drawLine(545 + (10 * i), 430, 510 + (10 * i), 600);
        }
        d.setColor(new Color(188, 186, 164));
        d.fillCircle(530, 440, 20);
        d.fillCircle(550, 460, 30);
        d.setColor(new Color(172, 170, 142));
        d.fillCircle(580, 425, 30);
        d.fillCircle(620, 435, 30);
        d.fillCircle(600, 465, 25);

    }

    /**
     * notify the sprite that time has passed.
     */
    public void timePassed() {

    }
}
