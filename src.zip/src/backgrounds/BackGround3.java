/*
 * Yuval Levy
 * 205781966
 */
package backgrounds;

import biuoop.DrawSurface;
import interfaces.Sprite;

import java.awt.Color;

/**
 * background of level3.
 *
 * @ author: Yuval Levy
 */
public class BackGround3 implements Sprite {
    /**
     * draw the sprite on the screen.
     *
     * @param d - the DrawSurface.
     */
    public void drawOn(DrawSurface d) {
        d.setColor(new Color(102, 208, 136));
        d.fillRectangle(0, 20, 800, 600);
        d.setColor(Color.BLACK);
        d.fillRectangle(100, 200, 10, 200);
        d.setColor(Color.BLACK);
        d.fillRectangle(90, 360, 30, 40);
        d.setColor(Color.BLACK);
        d.fillRectangle(50, 400, 100, 200);
        d.setColor(Color.WHITE);
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 5; j++) {
                d.fillRectangle(60 + (20 * j), (410 + (30 * i)), 10, 20);

            }
        }
        d.setColor(Color.YELLOW);
        d.fillCircle(105, 190, 12);
        d.setColor(Color.ORANGE);
        d.fillCircle(105, 190, 6);
        d.setColor(Color.WHITE);
        d.fillCircle(105, 190, 3);
    }

    /**
     * notify the sprite that time has passed.
     */
    public void timePassed() {

    }
}
