/*
 * Yuval Levy
 * 205781966
 */
package backgrounds;

import biuoop.DrawSurface;
import interfaces.Sprite;

import java.awt.Image;
import java.awt.Color;

/**
 * drawing the background with color or image. only one of them.
 */
public class LevelBackground implements Sprite {
    //fields
    private Color color;
    private Image image;

    /**
     * constructor.
     *
     * @param color the color
     * @param image the image
     */
    public LevelBackground(Color color, Image image) {
        this.color = color;
        this.image = image;
    }

    /**
     * draw the sprite on the screen.
     *
     * @param d - the DrawSurface.
     */
    public void drawOn(DrawSurface d) {
        if (this.image != null) {
            d.drawImage(0, 0, this.image);
        } else {
            d.setColor(color);
            d.fillRectangle(0, 0, d.getWidth(), d.getHeight());
        }
    }

    /**
     * notify the sprite that time has passed.
     */
    public void timePassed() {

    }
}
