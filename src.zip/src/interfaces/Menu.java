/*
 * Yuval Levy
 * 205781966
 */
package interfaces;

/**
 * each option of menu selection has a key that pressed, a message and returnVal
 *
 * @param <T> a general object.
 */
public interface Menu<T> extends Animation {
    /**
     * Add a new selection to main menu.
     *
     * @param key       the key
     * @param message   the message
     * @param returnVal the return val
     */
    void addSelection(String key, String message, T returnVal);

    /**
     * doing something according to the status.
     *
     * @return the status
     */
    T getStatus();

    /**
     * Add sub menu.
     *
     * @param key     the key
     * @param message the message
     * @param subMenu the sub menu
     */
    void addSubMenu(String key, String message, Menu<T> subMenu);
}
