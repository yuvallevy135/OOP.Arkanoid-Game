/*
 * Yuval Levy
 * 205781966
 */

package interfaces;

import geomrtyshapes.Ball;
import geomrtyshapes.Point;
import geomrtyshapes.Rectangle;
import geomrtyshapes.Velocity;

/**
 * The interface will show objects we can collide with.
 *
 * @ author: Yuval Levy
 */
public interface Collidable {
    /**
     * the func returns the object we collided with.
     *
     * @return the object of the colliding object.
     */
    Rectangle getCollisionRectangle();

    /**
     * if there was a collision with this object, the func will returns the new velocity afer the hit.
     *
     * @param hitter          - the ball that hit.
     * @param collisionPoint  the collision point
     * @param currentVelocity the current velocity of the colliding object.
     * @return the new velocity
     */
    Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity);
}
