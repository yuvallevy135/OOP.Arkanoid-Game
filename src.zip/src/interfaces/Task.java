/*
 * Yuval Levy
 * 205781966
 */
package interfaces;

/**
 * a task that something needs to happend or to run and return value..
 *
 * @param <T> the type parameter
 */
public interface Task <T> {
    /**
     * Run the describe the animation after we pressed the key.
     *
     * @return the t
     */
    T run();
}
