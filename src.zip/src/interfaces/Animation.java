/*
 * Yuval Levy
 * 205781966
 */

package interfaces;

import biuoop.DrawSurface;

/**
 * describes different animations that we will run while playing the game.
 */
public interface Animation {

    /**
     * in charge of the logic of each animation.
     *
     * @param d this drawsurface.
     */
    void doOneFrame(DrawSurface d);

    /**
     * determines when to stop the interfaces.Animation. Once this function returns true the animation will stop,
     * otherwise it will run.
     *
     * @return Boolean.
     */
    boolean shouldStop();
}