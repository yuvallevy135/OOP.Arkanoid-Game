/*
 * Yuval Levy
 * 205781966
 */
package interfaces;


import geomrtyshapes.Velocity;
import paddleandblock.Block;

import java.util.List;

/**
 * specifies the information required to fully describe a level.
 */
public interface LevelInformation {
    /**
     * number of balls in this Level.
     *
     * @return number of balls in this level.
     */
    int numberOfBalls();

    /**
     * The initial velocity of each ball, Note that initialBallVelocities().size() == numberOfBalls().
     *
     * @return list that contains all the velocity of each ball correspondingly
     */

    List<Velocity> initialBallVelocities();

    /**
     * the paddle's Velocity.
     *
     * @return the paddle's velocity.
     */
    int paddleSpeed();

    /**
     * The Paddle's Width.
     *
     * @return the paddle's width.
     */
    int paddleWidth();

    /**
     * the level name will be displayed at the top of the screen.
     *
     * @return string with the level's Name
     */
    String levelName();

    /**
     * Returns a sprite with the background of the level.
     *
     * @return the background
     */
    Sprite getBackground();

    /**
     * The Blocks that make up this level, each block contains.
     * its size, color and location.
     *
     * @return list of Blocks that contains all the Blocks in this Level
     */
    List<Block> blocks();

    /**
     * Number of levels that should be removed.
     * before the level is considered to be "cleared".
     * This number should be <= blocks.size().
     *
     * @return int Number of levels that should be removed before we skip to the next level.
     */
    int numberOfBlocksToRemove();
}
