/*
 * Yuval Levy
 * 205781966
 */

package interfaces;

import biuoop.DrawSurface;

/**
 * a interfaces.Sprite is a game object that can be on the screen - not a background. it can be notified that time has
 * passed.
 * so we will know to change their position, shape etc.
 *
 * @ author: Yuval Levy
 */
public interface Sprite {
    /**
     * the func draw the sprites on the surface.
     *
     * @param d the draw surface.
     */
    void drawOn(DrawSurface d);

    /**
     * notify the sprite that time has passed.
     */
    void timePassed();
}