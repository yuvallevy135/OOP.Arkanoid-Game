/*
 * Yuval Levy
 * 205781966
 */

package interfaces;

/**
 * it indicates objects that implement this interface and tells them when they are being hit.
 *
 * @ author: Yuval Levy
 */
public interface HitNotifier {
    /**
     * Add hl as a listener to hit events.
     *
     * @param hl its an object that is notified of the hit events.
     */
    void addHitListener(HitListener hl);

    /**
     * Remove hl from the list of listeners to hit events.
     *
     * @param hl its an object that is notified of the hit events.
     */
    void removeHitListener(HitListener hl);
}