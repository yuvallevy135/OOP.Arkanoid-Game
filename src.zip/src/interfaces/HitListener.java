/*
 * Yuval Levy
 * 205781966
 */

package interfaces;

import paddleandblock.Block;
import geomrtyshapes.Ball;

/**
 * An object that wants to be notified of the hit event needs to implement this interface.
 *
 * @ author: Yuval Levy
 */
public interface HitListener {
    /**
     * This method is called whenever the beingHit object is hit.
     * The hitter parameter is the geomrtyshapes.Ball that's doing the hitting.
     *
     * @param beingHit the paddleandblock.Block that was involved in the hit
     * @param hitter   the geomrtyshapes.Ball that was involved in the hit
     */

    void hitEvent(Block beingHit, Ball hitter);
}