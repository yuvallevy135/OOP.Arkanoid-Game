/*
 * Yuval Levy
 * 205781966
 */
package gamelevels;

import backgrounds.BackGround4;
import paddleandblock.Block;
import geomrtyshapes.Point;
import geomrtyshapes.Rectangle;
import geomrtyshapes.Velocity;
import interfaces.LevelInformation;
import interfaces.Sprite;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;


/**
 * describes level 4.
 *
 * @ author: Yuval Levy
 */
public class Level4 implements LevelInformation {
    /**
     * number of balls in this Level.
     *
     * @return 1
     */
    public int numberOfBalls() {
        return 2;
    }

    /**
     * The initial velocity of each ball, Note that initialBallVelocities().size() == numberOfBalls().
     *
     * @return List<assistingclasses.Velocity> velocityOfBalls
     */
    public List<Velocity> initialBallVelocities() {
        Velocity velocity1 = new Velocity(60, 5);
        Velocity velocity2 = new Velocity(0, 5);
        Velocity velocity3 = new Velocity(300, 5);
        List<Velocity> velocityOfBalls = new ArrayList<Velocity>();
        velocityOfBalls.add(velocity1);
        velocityOfBalls.add(velocity2);
        velocityOfBalls.add(velocity3);
        return velocityOfBalls;
    }

    /**
     * the spritesandcollidables.Paddle's assistingclasses.Velocity.
     *
     * @return 8
     */
    public int paddleSpeed() {
        return 8;
    }

    /**
     * The spritesandcollidables.Paddle's Width.
     *
     * @return 100
     */
    public int paddleWidth() {
        return 100;
    }

    /**
     * the level name will be displayed at the top of the screen.
     *
     * @return "Final Four"
     */
    public String levelName() {
        return ("Final Four");
    }

    /**
     * Returns a sprite with the background of the level.
     *
     * @return backGround4 background
     */
    public Sprite getBackground() {
        BackGround4 backGround4 = new BackGround4();
        return backGround4;
    }

    /**
     * The Blocks that make up this level, each block contains.
     * its size, color and location.
     *
     * @return List<spritesandcollidables.Block> blocksList
     */
    public List<Block> blocks() {
        List<Block> blockList = new ArrayList<Block>();
        Point upperLeftPoint;
        Rectangle gameRectangle;
        Color rectangleColor;
        int blockLife;
        Block block;
        for (int i = 1; i < 7; i++) {
            // all the blocks in each line are going to have the same hight.
            double heightRectangle = 20 * i;
            // here we will create each block in each line.
            for (int j = 0; j < 15; j++) {
                // each line will get a different color.
                if (i == 0) {
                    rectangleColor = Color.GRAY;
                } else if (i == 1) {
                    rectangleColor = Color.RED;
                } else if (i == 2) {
                    rectangleColor = Color.YELLOW;
                } else if (i == 3) {
                    rectangleColor = Color.GREEN;
                } else if (i == 4) {
                    rectangleColor = Color.WHITE;
                } else if (i == 5) {
                    rectangleColor = Color.PINK;
                } else {
                    rectangleColor = Color.CYAN;
                }
                // the width of each block at the same line will be 50 so it will be easy to calculate.
                double widthRectangle = (double) ((760.0 / 15.0) * j);
                // create the upper left point of the block.
                upperLeftPoint = new Point((20 + widthRectangle), (100 + heightRectangle));
                // create the rectangle of the block.
                gameRectangle = new Rectangle(upperLeftPoint, 50, 20);
                // the first block lines get life of 2 hits., the rest will get 1.
                if (i == 0) {
                    blockLife = 2;
                } else {
                    blockLife = 1;
                }
                // create the block.
                block = new Block(gameRectangle, rectangleColor, blockLife);
                // add the block to the game.
                blockList.add(block);
            }
        }
        return blockList;
    }

    /**
     * Number of levels that should be removed.
     * before the level is considered to be "cleared".
     * This number should be <= blocks.size().
     *
     * @return 105
     */
    public int numberOfBlocksToRemove() {
        return 105;
    }
}
