/*
 * Yuval Levy
 * 205781966
 */
package gamelevels;

import animation.AnimationRunner;
import animation.CountdownAnimation;
import animation.KeyPressStoppableAnimation;
import animation.PauseScreen;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import paddleandblock.Block;
import gamelevels.GameEnvironment;
import paddleandblock.Paddle;
import gamelevels.SpriteCollection;
import geomrtyshapes.Ball;
import geomrtyshapes.Point;
import geomrtyshapes.Rectangle;
import indicators.Counter;
import geomrtyshapes.Velocity;
import geomrtyshapes.BallRemover;
import paddleandblock.BlockRemover;
import indicators.ScoreTrackingListener;
import indicators.LevelNameIndicator;
import indicators.LivesIndicator;
import indicators.ScoreIndicator;
import interfaces.Collidable;
import interfaces.LevelInformation;
import interfaces.Sprite;
import interfaces.Animation;

import java.awt.Color;

/**
 * contains an Arraylist with all the sprites, collidables.
 *
 * @ author: Yuval Levy
 */
public class GameLevel implements Animation {
    private AnimationRunner runner;
    private boolean running;
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private Counter remainBlocks;
    private Counter remainBalls;
    private Counter score;
    private Counter numOfLives;
    private KeyboardSensor keyboard;
    private LevelInformation levelInfo;

    /**
     * constructor.
     *
     * @param runner     animation.AnimationRunner object.
     * @param score      the score
     * @param numOfLives the num of lives
     * @param levelInfo  the level info
     */
    public GameLevel(AnimationRunner runner, Counter score, Counter numOfLives, LevelInformation levelInfo) {
        this.runner = runner;
        this.sprites = new SpriteCollection();
        this.environment = new GameEnvironment();
        this.remainBlocks = new Counter(0);
        this.remainBalls = new Counter(0);
        this.score = score;
        this.numOfLives = numOfLives;
        this.keyboard = this.runner.getGui().getKeyboardSensor();
        this.levelInfo = levelInfo;

    }

    /**
     * the func gets a new collidable and adds it to the gamelevels.GameEnvironment's list.
     *
     * @param c new collidable
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }

    /**
     * the func adds the new sprite to the list..
     *
     * @param s the sprite we want to add to the sprites list.
     */
    public void addSprite(Sprite s) {
        this.sprites.addSprite(s);
    }

    /**
     * this func initializes the new game. it creates all the blocks.
     */
    public void initialize() {
        LevelNameIndicator levelName = new LevelNameIndicator(levelInfo);
        levelName.addToGame(this);
        LivesIndicator livesIndicator = new LivesIndicator(numOfLives);
        livesIndicator.addToGame(this);
        ScoreIndicator scoreIndicator = new ScoreIndicator(score);
        scoreIndicator.addToGame(this);
        ScoreTrackingListener countScore = new ScoreTrackingListener(this.score);
        BallRemover ballRemover = new BallRemover(this, remainBalls);
        BlockRemover blockRemover = new BlockRemover(this, this.remainBlocks);
        // create the 4 sides blocks.
        Rectangle topRect = new Rectangle(new Point(0, 20), 800, 20);
        Block topBlock = new Block(topRect, Color.CYAN, 0);
        Rectangle leftRect = new Rectangle(new Point(0, 20), 20, 580);
        Block leftBlock = new Block(leftRect, Color.CYAN, 0);
        Rectangle bottomRect = new Rectangle(new Point(0, 600), 800, 0);
        Block bottomBlock = new Block(bottomRect, Color.CYAN, 0);
        bottomBlock.addHitListener(ballRemover);
        Rectangle rightRect = new Rectangle(new Point(780, 20), 20, 580);
        Block rightBlock = new Block(rightRect, Color.CYAN, 0);
        // add the blocks to the game.
        topBlock.addToGame(this);
        leftBlock.addToGame(this);
        bottomBlock.addToGame(this);
        rightBlock.addToGame(this);
        // creating the blocks for each level.
        for (Block gameBlock : levelInfo.blocks()) {
            gameBlock.addToGame(this);
            remainBlocks.increase(1);
            gameBlock.addHitListener(blockRemover);
            gameBlock.addHitListener(countScore);
        }
    }

    /**
     * Run the game.
     */
    public void run() {
        while (this.numOfLives.getValue() != 0) {
            playOneTurn();
        }
    }

    /**
     * Initialize balls above paddle.
     */
    public void initializeBallsAbovePaddle() {
        for (int i = 0; i < levelInfo.numberOfBalls(); i++) {
            Point center = new Point(400, 555);
            Velocity velocity = levelInfo.initialBallVelocities().get(i);
            Ball firstBall = new Ball(center, 5, Color.WHITE, new Point(20, 20), new Point(780, 580));
            firstBall.setGameEnvironment(environment);
            firstBall.setVelocity(velocity);
            firstBall.addToGame(this);
            this.remainBalls.increase(1);
        }
    }

    /**
     * the func playOneTurn starrs the game and start the animation loop. it call the initializeBallsAbovePaddle
     * to create the balls and the paddle. It counts the score of tha player and his lives.
     * the turn ends when the play lost his all lives or there are no more blocks in the game.
     */
    public void playOneTurn() {
        this.initializeBallsAbovePaddle();
        Rectangle gameRectanglePaddle = new Rectangle(new Point((800 - levelInfo.paddleWidth()) / 2.0, 560),
                levelInfo.paddleWidth(), 20);
        // create the paddle.
        Paddle paddle = new Paddle(keyboard, Color.ORANGE, gameRectanglePaddle, levelInfo.paddleSpeed(), 20,
                780);
        // add it to the game.
        paddle.addToGame(this);
        this.runner.run(new CountdownAnimation(2, 3, sprites, levelInfo));
        // countdown before turn starts.
        // use our runner to run the current animation -- which is one turn of
        // the game.
        this.running = true;
        this.runner.run(this);
        paddle.removeFromGame(this);
    }

    /**
     * Remove the given collidable from the collidable list of the game.
     *
     * @param c the collidable that we want to remove from the list.
     */
    public void removeCollidable(Collidable c) {
        this.environment.getCollidablesList().remove(c);

    }

    /**
     * Remove the given sprite from the sprites list of the game.
     *
     * @param s the sprit that we want to remove from the list.
     */
    public void removeSprite(Sprite s) {
        this.sprites.getAllSprites().remove(s);
    }

    /**
     * Gets the current score in the game.
     *
     * @return the score
     */
    public Counter getScore() {
        return this.score;
    }

    /**
     * Gets the num of lives that the player has at the moment.
     *
     * @return the num of lives
     */
    public int getNumOfLives() {
        return this.numOfLives.getValue();
    }

    /**
     * determines when to stop the interfaces.Animation. if true the animation will stop,
     *
     * @return Boolean needToStop.
     */
    public boolean shouldStop() {
        // ni more block - finish the game.
        if (this.remainBlocks.getValue() == 0) {
            return this.running;
        }
        if (this.remainBalls.getValue() == 0) {
            this.numOfLives.decrease(1);
            if (this.numOfLives.getValue() > 0) {
                return this.running;
            } else {
                // num of lives is - 0 then game over.
                return this.running;
            }
        }
        return !this.running;
    }

    /**
     * doing one frame of the turn each time. is the player pressed "p" then we will go
     * to a "pause" animation until he will press "space" to return to the turn.
     *
     * @param d this drawsurface
     */
    public void doOneFrame(DrawSurface d) {
        this.levelInfo.getBackground().drawOn(d);
        PauseScreen pauseScreen = new PauseScreen(keyboard);
        KeyPressStoppableAnimation pauseScreenK = new KeyPressStoppableAnimation(keyboard, "space", pauseScreen);
        this.sprites.drawAllOn(d);
        this.sprites.notifyAllTimePassed();
        if (this.keyboard.isPressed("p")) {
            this.runner.run(pauseScreenK);
        }
    }

    /**
     * Gets num of blocks.
     *
     * @return the num of blocks
     */
    public int getNumOfBlocks() {
        return this.remainBlocks.getValue();
    }
}
