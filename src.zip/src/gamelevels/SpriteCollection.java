/*
 * Yuval Levy
 * 205781966
 */

package gamelevels;

import biuoop.DrawSurface;
import interfaces.Sprite;

import java.util.ArrayList;
import java.util.List;


/**
 * The  interfaces.Sprite collection has an array list of all the sprites in the game.
 *
 * @ author: Yuval Levy
 */
public class SpriteCollection {
    private List<Sprite> allSprites;

    /**
     * constructor.
     */
    public SpriteCollection() {
        this.allSprites = new ArrayList<Sprite>();
    }

    /**
     * Add the new sprite to the game.
     *
     * @param s the new sprite.
     */
    public void addSprite(Sprite s) {
        allSprites.add(s);
    }

    /**
     * call timePassed() on all sprites..
     */
    public void notifyAllTimePassed() {
        List<Sprite> spriteList = new ArrayList<Sprite>(this.allSprites);
        for (Sprite spriteObject : spriteList) {
            spriteObject.timePassed();
        }
    }

    /**
     * call drawOn(d) on all sprites. draw them on the surface.
     *
     * @param d the surface.
     */
    public void drawAllOn(DrawSurface d) {
        for (Sprite spriteObject : allSprites) {
            spriteObject.drawOn(d);
        }
    }

    /**
     * Gets a list with all the sprites in the game.
     *
     * @return this.allSprites  all sprites
     */
    public List<Sprite> getAllSprites() {
        return this.allSprites;
    }
}