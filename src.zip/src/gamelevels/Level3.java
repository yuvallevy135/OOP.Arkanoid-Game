/*
 * Yuval Levy
 * 205781966
 */
package gamelevels;

import backgrounds.BackGround3;
import paddleandblock.Block;
import geomrtyshapes.Point;
import geomrtyshapes.Rectangle;
import geomrtyshapes.Velocity;
import interfaces.LevelInformation;
import interfaces.Sprite;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * describes level 3.
 *
 * @ author: Yuval Levy
 */
public class Level3 implements LevelInformation {
    /**
     * number of balls in this Level.
     *
     * @return 2
     */
    public int numberOfBalls() {
        return 2;
    }

    /**
     * The initial velocity of each ball, Note that initialBallVelocities().size() == numberOfBalls().
     *
     * @return List<assistingclasses.Velocity> velocityOfBalls
     */
    public List<Velocity> initialBallVelocities() {
        Velocity velocity1 = new Velocity(4, 4);
        Velocity velocity2 = new Velocity(5, 5);
        List<Velocity> velocityOfBalls = new ArrayList<Velocity>();
        velocityOfBalls.add(velocity1);
        velocityOfBalls.add(velocity2);
        return velocityOfBalls;
    }

    /**
     * the spritesandcollidables.Paddle's assistingclasses.Velocity.
     *
     * @return 8
     */
    public int paddleSpeed() {
        return 8;
    }

    /**
     * The spritesandcollidables.Paddle's Width.
     *
     * @return 130
     */
    public int paddleWidth() {
        return 130;
    }

    /**
     * the level name will be displayed at the top of the screen.
     *
     * @return "Green 3"
     */
    public String levelName() {
        return ("Green 3");
    }

    /**
     * Returns a sprite with the background of the level.
     *
     * @return backGround3 background
     */
    public Sprite getBackground() {
        BackGround3 backGround3 = new BackGround3();
        return backGround3;
    }

    /**
     * The Blocks that make up this level, each block contains.
     * its size, color and location.
     *
     * @return List<spritesandcollidables.Block> blocksList
     */
    public List<Block> blocks() {
        List<Block> blockList = new ArrayList<Block>();
        Point upperLeftPoint;
        Rectangle gameRectangle;
        Color rectangleColor;
        int blockLife;
        Block block;
        for (int i = 1; i < 6; i++) {
            // all the blocks in each line are going to have the same hight.
            double heightRectangle = 20 * i;
            // here we will create each block in each line.
            for (int j = i; j < 11; j++) {
                // each line will get a different color.
                if (i == 1) {
                    rectangleColor = Color.GRAY;
                } else if (i == 2) {
                    rectangleColor = Color.RED;
                } else if (i == 3) {
                    rectangleColor = Color.YELLOW;
                } else if (i == 4) {
                    rectangleColor = Color.BLUE;
                } else {
                    rectangleColor = Color.WHITE;
                }
                // the width of each block at the same line will be 50 so it will be easy to calculate.
                double widthRectangle = 50 * j;
                // create the upper left point of the block.
                upperLeftPoint = new Point((180 + widthRectangle), (100 + heightRectangle));
                // create the rectangle of the block.
                gameRectangle = new Rectangle(upperLeftPoint, 50, 20);
                // the first block lines get life of 2 hits., the rest will get 1.
                if (i == 0) {
                    blockLife = 2;
                } else {
                    blockLife = 1;
                }
                // create the block.
                block = new Block(gameRectangle, rectangleColor, blockLife);
                // add the block to the game.
                blockList.add(block);
            }
        }
        return blockList;
    }

    /**
     * Number of levels that should be removed.
     * before the level is considered to be "cleared".
     * This number should be <= blocks.size().
     *
     * @return 57
     */
    public int numberOfBlocksToRemove() {
        return 40;
    }
}
