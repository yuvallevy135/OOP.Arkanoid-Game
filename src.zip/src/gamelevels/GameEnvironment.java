/*
 * Yuval Levy
 * 205781966
 */
package gamelevels;

import geomrtyshapes.Line;
import geomrtyshapes.Point;
import geomrtyshapes.CollisionInfo;
import interfaces.Collidable;

import java.util.List;
import java.util.ArrayList;

/**
 * gamelevels.Game environment has an array list with all the collidables in the game.
 *
 * @ author: Yuval Levy
 */
public class GameEnvironment {

    //fields.
    private List<Collidable> collidablesList;

    /**
     * constructor.
     */
    public GameEnvironment() {
        this.collidablesList = new ArrayList<Collidable>();
    }

    /**
     * the func gets a new collidable  and adds it to the collidables list.
     *
     * @param c new collidable
     */
    public void addCollidable(Collidable c) {
        this.collidablesList.add(c);

    }

    /**
     * this func checks if an object collides any other collidables or not.
     * if there was collision the func will return the info about the closest collision point.
     * else it will return null.
     *
     * @param trajectory the moving course of the object.
     * @return the closest collision point.
     */
    public CollisionInfo getClosestCollision(Line trajectory) {
        // setting a distance for the start of the line and a potential collision.
        double distance = 0;
        // setting a temp distance to compare with the other distance.
        double tempDistance;
        // setting the closestCollision point. for a start its null until found one.
        Point closestPoint = null;
        // setting a tempClosestPoint. every time it will be the new point until we will compare the distances.
        Point tempClosestPoint;
        // the chosen collidable object. for start its null until found one.
        Collidable chosenCollidable = null;
        // setting a collision info if found one.
        CollisionInfo collisionInfo;
        // setting number of points just in case there are more them 1 points to compare.
        int numOfPoints = 0;
        // the loop will go over all the collidable objects and check if there are collision point and
        // which one is the closest.
        for (Collidable collidable : collidablesList) {
            // if a collidable point was found.
            if (trajectory.closestIntersectionToStartOfLine(collidable.getCollisionRectangle()) != null) {
                // we will set the distance between the start of the trajectory and the collision point.
                tempDistance = trajectory.getStart().distance(trajectory.closestIntersectionToStartOfLine(
                        collidable.getCollisionRectangle()));
                // we will set this point as a temp point until checked if this is the closest one.
                tempClosestPoint = trajectory.closestIntersectionToStartOfLine(collidable.getCollisionRectangle());
                // if there are no collidable points yet then for now this point is the closest one.
                if (numOfPoints == 0) {
                    distance = tempDistance;
                    closestPoint = tempClosestPoint;
                    chosenCollidable = collidable;
                    numOfPoints++;
                } else {
                    // if there are more then one collidable point
                    // we will check the distances between the new point and the old point and
                    // decide which one is the closest.
                    if (tempDistance < distance) {
                        // a new closest point was found. store this distance.
                        distance = tempDistance;
                        closestPoint = tempClosestPoint;
                        chosenCollidable = collidable;
                    }
                }
            }
        }
        // if we didn't find any collision point.
        if (numOfPoints == 0) {
            return null;
        } else {
            // there is a closest point. return that collisionInfo.
            collisionInfo = new CollisionInfo(closestPoint, chosenCollidable);
            return collisionInfo;
        }
    }

    /**
     * Gets collidables list.
     *
     * @return the collidables list
     */
    public List<Collidable> getCollidablesList() {
        return this.collidablesList;
    }
}