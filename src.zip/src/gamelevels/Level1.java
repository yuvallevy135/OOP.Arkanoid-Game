/*
 * Yuval Levy
 * 205781966
 */
package gamelevels;

import backgrounds.BackGround1;
import paddleandblock.Block;
import geomrtyshapes.Velocity;
import interfaces.LevelInformation;
import interfaces.Sprite;
import geomrtyshapes.Rectangle;
import geomrtyshapes.Point;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * describes level 1.
 *
 * @ author: Yuval Levy
 */
public class Level1 implements LevelInformation {
    /**
     * number of balls in this Level.
     *
     * @return 1
     */
    public int numberOfBalls() {
        return 1;
    }

    /**
     * The initial velocity of each ball, Note that initialBallVelocities().size() == numberOfBalls().
     *
     * @return List<assistingclasses.Velocity> velocityOfBalls
     */
    public List<Velocity> initialBallVelocities() {
        Velocity velocity = new Velocity(0, 5);
        List<Velocity> velocityOfBalls = new ArrayList<Velocity>();
        velocityOfBalls.add(velocity);
        return velocityOfBalls;
    }

    /**
     * the spritesandcollidables.Paddle's assistingclasses.Velocity.
     *
     * @return 8
     */
    public int paddleSpeed() {
        return 8;
    }

    /**
     * The spritesandcollidables.Paddle's Width.
     *
     * @return 80
     */
    public int paddleWidth() {
        return 80;
    }

    /**
     * the level name will be displayed at the top of the screen.
     *
     * @return "Direct Hit"
     */
    public String levelName() {
        return ("Direct Hit");
    }

    /**
     * Returns a sprite with the background of the level.
     *
     * @return backGround1 background
     */
    public Sprite getBackground() {
        BackGround1 backGround1 = new BackGround1();
        return backGround1;
    }

    /**
     * The Blocks that make up this level, each block contains:
     * its size, color and location.
     *
     * @return List<spritesandcollidables.Block> blocksList
     */
    public List<Block> blocks() {
        List<Block> blockList = new ArrayList<Block>();
        Point blockP = new Point(385, 185);
        Rectangle rectangle = new Rectangle(blockP, 30, 30);
        Block block = new Block(rectangle, Color.RED, 1);
        blockList.add(block);
        return blockList;
    }

    /**
     * Number of levels that should be removed.
     * before the level is considered to be "cleared".
     * This number should be <= blocks.size().
     *
     * @return 1
     */
    public int numberOfBlocksToRemove() {
        return 1;
    }
}
