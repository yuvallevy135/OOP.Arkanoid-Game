/*
 * Yuval Levy
 * 205781966
 */
package gamelevels;

import backgrounds.BackGround2;
import paddleandblock.Block;
import geomrtyshapes.Point;
import geomrtyshapes.Rectangle;
import geomrtyshapes.Velocity;
import interfaces.LevelInformation;
import interfaces.Sprite;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * describes level 2.
 *
 * @ author: Yuval Levy
 */
public class Level2 implements LevelInformation {
    /**
     * number of balls in this Level.
     *
     * @return 10
     */
    public int numberOfBalls() {
        return 10;
    }

    /**
     * The initial velocity of each ball, Note that initialBallVelocities().size() == numberOfBalls().
     *
     * @return List<assistingclasses.Velocity> velocityOfBalls
     */
    public List<Velocity> initialBallVelocities() {
        Velocity velocity;
        List<Velocity> velocityOfBalls = new ArrayList<Velocity>();
        for (int i = 0; i < 10; i++) {
            velocity = Velocity.fromAngleAndSpeed(120 + (i * (120 / 9)), 8);
            velocityOfBalls.add(velocity);
        }
        return velocityOfBalls;
    }

    /**
     * the spritesandcollidables.Paddle's assistingclasses.Velocity.
     *
     * @return 5
     */
    public int paddleSpeed() {
        return 5;
    }

    /**
     * The spritesandcollidables.Paddle's Width.
     *
     * @return 450
     */
    public int paddleWidth() {
        return 450;
    }

    /**
     * the level name will be displayed at the top of the screen.
     *
     * @return "Wide Easy"
     */
    public String levelName() {
        return ("Wide Easy");
    }

    /**
     * Returns a sprite with the background of the level.
     *
     * @return backGround2 background
     */
    public Sprite getBackground() {
        BackGround2 backGround2 = new BackGround2();
        return backGround2;
    }

    /**
     * The Blocks that make up this level, each block contains.
     * its size, color and location.
     *
     * @return List<spritesandcollidables.Block> blocksList
     */
    public List<Block> blocks() {
        List<Block> blockList = new ArrayList<Block>();
        Point point;
        Rectangle rectangle;
        Color color;
        for (int i = 0; i < 15; i++) {
            if (i == 0 || i == 1) {
                color = Color.RED;
            } else if (i == 2 || i == 3) {
                color = Color.ORANGE;
            } else if (i == 4 || i == 5) {
                color = Color.yellow;
            } else if (i == 6 || i == 7 || i == 8) {
                color = Color.GREEN;
            } else if (i == 9 || i == 10) {
                color = Color.BLUE;
            } else if (i == 11 || i == 12) {
                color = Color.PINK;
            } else {
                color = Color.CYAN;
            }
            point = new Point(20 + (i * (760 / 15.0)), 230);
            rectangle = new Rectangle(point, 760 / 15.0, 20);
            Block block = new Block(rectangle, color, 1);
            blockList.add(block);
        }
        return blockList;
    }

    /**
     * Number of levels that should be removed.
     * before the level is considered to be "cleared".
     * This number should be <= blocks.size().
     *
     * @return 15
     */
    public int numberOfBlocksToRemove() {
        return 15;
    }
}