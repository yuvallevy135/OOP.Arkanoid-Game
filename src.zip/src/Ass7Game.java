/*
 * Yuval Levy
 * 205781966
 */

import biuoop.GUI;
import animation.MenuAnimation;
import animation.AnimationRunner;
import biuoop.KeyboardSensor;
import fromfiles.LevelSpecificationReader;
import interfaces.LevelInformation;
import interfaces.Task;
import interfaces.Menu;
import tasks.ShowGame;
import tasks.CloseGame;
import tasks.ShowHiScoresTask;
import thehighscoretablepackage.GameFlow;
import thehighscoretablepackage.HighScoresAnimation;
import thehighscoretablepackage.HighScoresTable;

import java.io.InputStreamReader;
import java.io.LineNumberReader;

import java.io.InputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * create the game, initialize and runs it.
 */
public class Ass7Game {

    /**
     * raed from each level set.
     *
     * @param ar          the ar
     * @param menu        the menu
     * @param levelPath   the level path
     * @param ks          the ks
     * @param scoresTable the scores table
     */
    public static void levelRead(AnimationRunner ar, Menu<Task<Void>> menu,
                                 String levelPath, KeyboardSensor ks, HighScoresTable scoresTable) {
        try {
            String stringLine;
            InputStreamReader is =
                    new InputStreamReader(ClassLoader.getSystemClassLoader().getResourceAsStream(levelPath));
            LineNumberReader lineNumberReader = new LineNumberReader(is);
            stringLine = lineNumberReader.readLine();
            String stringLeft;
            String stringRight = null;
            String[] colonArr;
            String stopIt = null;
            List<LevelInformation> theLevels;
            while (stringLine != null) {
                if (lineNumberReader.getLineNumber() % 2 == 0) {
                    try {
                        InputStream inputStream = ClassLoader.getSystemClassLoader().getResourceAsStream(stringLine);
                        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                        LevelSpecificationReader levelSpecificationReader = new LevelSpecificationReader();
                        theLevels = levelSpecificationReader.fromReader(inputStreamReader);
                        ShowGame showGame = new ShowGame(new GameFlow(ar, ks, scoresTable), theLevels);
                        menu.addSelection(stopIt, stringRight, showGame);
                    } catch (Exception e) {
                        System.out.println("Something happened while trying to read the set level text file.");
                    }
                } else {
                    colonArr = stringLine.split(":");
                    stringLeft = colonArr[0].trim();
                    stopIt = stringLeft.substring(0, 1);
                    stringRight = colonArr[1].trim();
                }
                stringLine = lineNumberReader.readLine();
            }
        } catch (Exception e) {
            System.out.println("Cant read from level set text file");
        }
    }

    /**
     * the main method.
     *
     * @param args no params.
     */
    public static void main(String[] args) {
        String textFile;
        if (args.length >= 1) {
            textFile = args[0];
        } else {
            textFile = "level_sets.txt";
        }
        GUI gui = new GUI("Arkanoid", 800, 600);
        List<LevelInformation> theLevel = new ArrayList<>();
        AnimationRunner ar = new AnimationRunner(gui, 60);
        KeyboardSensor ks = gui.getKeyboardSensor();
        LevelSpecificationReader levelSpecificationReader = new LevelSpecificationReader();
        HighScoresTable scoresTable = new HighScoresTable(5);
        try {
            scoresTable.load(new File("highscores.txt"));
        } catch (Exception e) {
            System.out.println("Something happened while trying to load from the file");
        }
        while (true) {
            Menu<Task<Void>> menuLevel = new MenuAnimation<>(ar, "Game-Level", ks);
            levelRead(ar, menuLevel, textFile, ks, scoresTable);
            Menu<Task<Void>> menu = new MenuAnimation<Task<Void>>(ar, "Arkanoid-Game", ks);
            menu.addSubMenu("s", "Start Game", menuLevel);
            menu.addSelection("h", "High Scores Table",
                    new ShowHiScoresTask(ar, new HighScoresAnimation(scoresTable), ks));
            menu.addSelection("q", "Close Game", new CloseGame());
            ar.run(menu);
            Task<Void> task = menu.getStatus();
            task.run();
            ((MenuAnimation<Task<Void>>) menu).stopAnimation();
        }
    }

}

